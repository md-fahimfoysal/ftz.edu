import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { User, Country, University, Application, Staff, StorageConfig, Branding, SystemSettings, GlobalScholarship } from "./types";

// Import Custom components
import Header from "./components/Header";
import CountrySection from "./components/CountrySection";
import UniversitySection from "./components/UniversitySection";
import ScholarshipSection from "./components/ScholarshipSection";
import AboutUs from "./components/AboutUs";
import AdminPanel from "./components/AdminPanel";
import AgentPanel from "./components/AgentPanel";
import StudentPanel from "./components/StudentPanel";
import ApplicationModal from "./components/ApplicationModal";
import CountryUniversitiesModal from "./components/CountryUniversitiesModal";
import Messenger from "./components/Messenger";

// Lucide Icons
import {
  ShieldAlert,
  ArrowRight,
  Info,
  LogOut,
  Mail,
  Lock,
  UserCheck,
  Briefcase,
  Sparkles,
  Award,
  Globe,
  Building,
  GraduationCap,
  RefreshCw,
  ShieldAlert as AlertIcon,
  MessagesSquare,
  X
} from "lucide-react";

export default function App() {
  // Global App Configurations (syncing from backend)
  const [branding, setBranding] = useState<Branding>({
    name: "FTZ EDU CONSULTANCY",
    logoText: "FTZ",
    primaryColor: "indigo",
    emailContact: "ftz.edu.consultancy@gmail.com",
    emailContact2: "ftz.edu.consultancy@gmail.com"
  });

  const [storageConfig, setStorageConfig] = useState<StorageConfig>({
    destinationLink: "https://drive.google.com/drive/folders/default-shared-folder",
    provider: "Google Drive"
  });

  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    disableStudentLogin: false,
    disableStudentRegister: false,
    disableAgentLogin: false,
    disableAgentRegister: false
  });

  // DB datasets
  const [countries, setCountries] = useState<Country[]>([]);
  const [universities, setUniversities] = useState<University[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [scholarships, setScholarships] = useState<GlobalScholarship[]>([]);

  // Navigation states
  const [activeTab, setActiveTab] = useState<string>(() => {
    try {
      const stored = localStorage.getItem("portal_user");
      if (stored) {
        const u = JSON.parse(stored);
        if (u && u.status === "approved") {
          if (u.role === "admin") return "admin-panel";
          if (u.role === "agent") return "agent-panel";
          if (u.role === "student") return "student-panel";
        }
      }
    } catch (e) {
      console.error("Error reading stored user in tab initialization:", e);
    }
    return "home";
  }); // 'home' | 'scholarships' | 'about' | 'login' | 'admin-panel' | 'agent-panel' | 'student-panel'
  const [selectedCountryId, setSelectedCountryId] = useState<string | null>(null);

  // Authentication states
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem("portal_user");
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      return null;
    }
  });

  // Sync current user to local storage on changes
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem("portal_user", JSON.stringify(currentUser));
      } else {
        localStorage.removeItem("portal_user");
      }
    } catch (e) {
      console.error("Failed to write portal_user to localStorage:", e);
    }
  }, [currentUser]);

  // Messaging/WebSocket States
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [onlineUserIds, setOnlineUserIds] = useState<string[]>([]);
  const [unreadChatCount, setUnreadChatCount] = useState<number>(0);
  const [showGlobalMessenger, setShowGlobalMessenger] = useState<boolean>(false);

  // Auth Forms states
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [loginViewRole, setLoginViewRole] = useState<"student" | "agent" | "admin">("student");
  const [pendingApprovalUser, setPendingApprovalUser] = useState<{ email: string; name: string; role: string; password?: string } | null>(null);
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authRoleReg, setAuthRoleReg] = useState<"student" | "agent">("student");
  const [authAgentCountries, setAuthAgentCountries] = useState<string[]>([]);
  const [authError, setAuthError] = useState("");

  // Target application apply flow modal
  const [applyingUniversity, setApplyingUniversity] = useState<University | null>(null);

  // Load state from full-stack server
  const fetchAllData = async () => {
    try {
      const res = await fetch("/api/db");
      if (res.ok) {
        const data = await res.json();
        setCountries(data.countries || []);
        setUniversities(data.universities || []);
        setApplications(data.applications || []);
        setStaff(data.staff || []);
        setUsers(data.users || []);
        setScholarships(data.scholarships || []);
        setBranding(data.branding || branding);
        setStorageConfig(data.storageConfig || storageConfig);
        if (data.systemSettings) {
          setSystemSettings(data.systemSettings);
        }

        // Keep local profile sync if logged in
        if (currentUser) {
          const syncedUser = data.users.find((u: User) => u.id === currentUser.id);
          if (syncedUser) {
            setCurrentUser(syncedUser);
          }
        }
      }
    } catch (err) {
      console.error("Failed to connect to express server framework.", err);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [currentUser?.id]);

  // Synchronize document tab title dynamically with custom agency name instantly
  useEffect(() => {
    if (branding && branding.name) {
      document.title = branding.name;
    }
  }, [branding?.name]);

  // Messaging/WebSocket connection sync
  useEffect(() => {
    if (!currentUser) {
      if (socket) {
        socket.close();
        setSocket(null);
      }
      setOnlineUserIds([]);
      setUnreadChatCount(0);
      return;
    }

    const wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${wsProtocol}//${window.location.host}/ws?userId=${currentUser.id}`;
    
    let ws: WebSocket | null = null;
    let reconnectTimeout: any = null;
    let isCleanedUp = false;

    const connectWS = () => {
      if (isCleanedUp) return;
      ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        if (isCleanedUp) {
          ws?.close();
          return;
        }
        console.log("WebSocket connection established for:", currentUser.name);
        setSocket(ws);
      };

      ws.onmessage = (event) => {
        if (isCleanedUp) return;
        try {
          const data = JSON.parse(event.data);
          if (data.type === "presence_list") {
            setOnlineUserIds(data.onlineUserIds || []);
          } else if (data.type === "presence") {
            setOnlineUserIds((prev) => {
              if (data.isOnline) {
                if (prev.includes(data.userId)) return prev;
                return [...prev, data.userId];
              } else {
                return prev.filter((id) => id !== data.userId);
              }
            });
          } else if (data.type === "message") {
            // Re-fetch count of unread chat messages
            fetchUnreadChatNotifications();
          } else if (data.type === "seen") {
            // Handled inside Messenger, but can trigger recount here if needed
            fetchUnreadChatNotifications();
          }
        } catch (err) {
          console.error("Error reading global ws message:", err);
        }
      };

      ws.onclose = () => {
        setSocket(null);
        if (isCleanedUp) return;
        // Silent automatic reconnect attempt after 5 seconds if user is still active
        reconnectTimeout = setTimeout(() => {
          if (currentUser && !isCleanedUp) {
            connectWS();
          }
        }, 5000);
      };

      ws.onerror = (err) => {
        console.log("WebSocket optional connection event:", err);
      };
    };

    const fetchUnreadChatNotifications = async () => {
      if (isCleanedUp) return;
      try {
        const res = await fetch(`/api/chat/notifications?userId=${currentUser.id}`);
        if (res.ok && !isCleanedUp) {
          const notifications = await res.json();
          setUnreadChatCount(notifications.length);
        }
      } catch (err) {
        console.log("Error fetching unread count:", err);
      }
    };

    connectWS();
    fetchUnreadChatNotifications();

    // Fallback polling for unread counts if WebSocket connection is not active or has failed
    const pollInterval = setInterval(() => {
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        fetchUnreadChatNotifications();
      }
    }, 5000);

    return () => {
      isCleanedUp = true;
      if (ws) {
        ws.close();
      }
      if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
      }
      clearInterval(pollInterval);
    };
  }, [currentUser?.id]);

  // Logout handler
  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab("home");
    setSelectedCountryId(null);
    setAuthError("");
  };

  // Login handler
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authEmail.trim(),
          password: authPassword,
          isGoogleSignIn: false,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        
        // Redirect based on approval state and roles
        if (data.user.status === "pending") {
          setPendingApprovalUser({
            email: data.user.email,
            name: data.user.name,
            role: data.user.role,
          });
        } else {
          setCurrentUser(data.user);
          if (data.user.role === "admin") setActiveTab("admin-panel");
          else if (data.user.role === "agent") setActiveTab("agent-panel");
          else setActiveTab("student-panel");
        }
        
        setAuthPassword("");
      } else {
        const err = await res.json();
        if (err.error === "WAITING_FOR_ADMIN_APPROVAL") {
          setPendingApprovalUser({
            email: authEmail.trim(),
            name: authName || "User Account",
            role: loginViewRole,
          });
        } else {
          setAuthError(err.error || "Login credentials rejected.");
        }
      }
    } catch (err) {
      setAuthError("Failed to authenticate to host. Check connection.");
    }
  };



  // Registration handler
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");

    if (authRoleReg === "agent" && authAgentCountries.length === 0) {
      setAuthError("Please select at least one country you want to work/advise on.");
      return;
    }

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authEmail.trim(),
          name: authName,
          role: authRoleReg,
          password: authPassword,
          countries: authRoleReg === "agent" ? authAgentCountries : undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setPendingApprovalUser({
          email: authEmail.trim(),
          name: authName,
          role: authRoleReg,
        });
        setIsRegisterMode(false);
        setAuthPassword("");
        setAuthAgentCountries([]);
        fetchAllData();
      } else {
        const err = await res.json();
        setAuthError(err.error || "Registration rejected.");
      }
    } catch (err) {
      setAuthError("Server registration fail.");
    }
  };

  // Student application submit handler
  const handleApplicationSubmit = async (payload: any) => {
    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        alert("Application successfully initialized and catalogued! Track progress in your student dashboard.");
        await fetchAllData();
        setActiveTab("student-panel");
      } else {
        alert("Enrollment registry reject.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateSystemSettings = async (updated: Partial<SystemSettings>) => {
    try {
      const res = await fetch("/api/system-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });

      if (res.ok) {
        const data = await res.json();
        setSystemSettings(data);
        await fetchAllData();
      } else {
        alert("Failed to update system access policy gates.");
      }
    } catch (err) {
      console.error(err);
      alert("Error contacting platform gate controller service.");
    }
  };

  // Admin and Agent functions
  const handleApproveUser = async (uId: string) => {
    try {
      const res = await fetch(`/api/users/${uId}/approve`, { method: "PUT" });
      if (res.ok) {
        alert("Account approved! Advisor/Student can now logon safely.");
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateUserCredentials = async (uId: string, updated: Partial<User>) => {
    try {
      const res = await fetch(`/api/users/${uId}/credentials`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        alert("Account credentials updated successfully!");
        await fetchAllData();
      } else {
        const errorData = await res.json();
        alert(`Failed to update credentials: ${errorData.error || "Unknown error"}`);
      }
    } catch (err) {
      console.error(err);
      alert("Error contacting platform gate controller service.");
    }
  };

  const handleDeleteUser = async (uId: string) => {
    try {
      const res = await fetch(`/api/users/${uId}`, { method: "DELETE" });
      if (res.ok) {
        alert("User account removed.");
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateBranding = async (updated: Partial<Branding>) => {
    try {
      const res = await fetch("/api/branding", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const data = await res.json();
        setBranding(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateStorage = async (updated: Partial<StorageConfig>) => {
    try {
      const res = await fetch("/api/storage", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const data = await res.json();
        setStorageConfig(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateApplicationStatus = async (appId: string, status: string, notes: string, portalScreenshot?: string) => {
    try {
      const res = await fetch(`/api/applications/${appId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          updaterName: currentUser?.name || "Global Director",
          updaterRole: currentUser?.role || "admin",
          noteText: notes,
          portalScreenshot,
        }),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteApplication = async (appId: string) => {
    const confirmDelete = window.confirm("Are you sure you want to permanently delete this student application from the registry?");
    if (!confirmDelete) return;

    try {
      const res = await fetch(`/api/applications/${appId}`, {
        method: "DELETE"
      });
      if (res.ok) {
        await fetchAllData();
      } else {
        alert("Server failed to delete this student application.");
      }
    } catch (err) {
      console.error(err);
      alert("Error occurred deleting this application.");
    }
  };

  // Staff managers
  const handleAddStaff = async (newStaff: Omit<Staff, "id">) => {
    try {
      const res = await fetch("/api/staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newStaff),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateStaff = async (id: string, updated: Partial<Staff>) => {
    try {
      const res = await fetch(`/api/staff/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteStaff = async (id: string) => {
    try {
      const res = await fetch(`/api/staff/${id}`, { method: "DELETE" });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Countries managers
  const handleAddCountry = async (newCountry: Omit<Country, "id">) => {
    try {
      const res = await fetch("/api/countries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCountry),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateCountry = async (id: string, updated: Partial<Country>) => {
    try {
      const res = await fetch(`/api/countries/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteCountry = async (id: string) => {
    try {
      const res = await fetch(`/api/countries/${id}`, { method: "DELETE" });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Universities managers
  const handleAddUniversity = async (newUni: Omit<University, "id">) => {
    try {
      const res = await fetch("/api/universities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUni),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateUniversity = async (id: string, updated: Partial<University>) => {
    try {
      const res = await fetch(`/api/universities/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteUniversity = async (id: string) => {
    try {
      const res = await fetch(`/api/universities/${id}`, { method: "DELETE" });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Scholarships managers
  const handleAddScholarship = async (newSch: Omit<GlobalScholarship, "id">) => {
    try {
      const res = await fetch("/api/scholarships", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSch),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateScholarship = async (id: string, updated: Partial<GlobalScholarship>) => {
    try {
      const res = await fetch(`/api/scholarships/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteScholarship = async (id: string) => {
    try {
      const res = await fetch(`/api/scholarships/${id}`, { method: "DELETE" });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Upload student profile photo
  const handleUploadProfilePhoto = async (photoUrl: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/users/${currentUser.id}/profile-photo`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl: photoUrl })
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Open apply trigger: check status/login
  const handleInitiatingApply = (uni: University) => {
    if (!currentUser) {
      alert("Please login as a registered verified student before initiating university application portfolios.");
      setActiveTab("login");
      return;
    }
    if (currentUser.status === "pending") {
      alert("Your student account is currently in pending state. An Administrator must first approve your account inside the Admin registry tab.");
      return;
    }
    setApplyingUniversity(uni);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900" id="global-edu-app">
      {/* Top Header branding bar */}
      <Header
        user={currentUser}
        onLogout={handleLogout}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        branding={branding}
        unreadCount={unreadChatCount}
        onOpenChat={() => setShowGlobalMessenger(true)}
      />

      {/* Pending Approval warning banner */}
      {currentUser && currentUser.status === "pending" && (
        <div className="bg-amber-650 text-white font-bold py-3.5 px-4 text-xs tracking-wide flex items-center justify-center gap-1.5 shadow-sm" id="pending-reg-warning">
          <ShieldAlert className="w-4 h-4 text-amber-100 shrink-0" />
          <span>Account pending administrator verification. Please contact {branding.emailContact} to activate registration details.</span>
        </div>
      )}

      {/* Main Core Content Stage */}
      <main className="flex-1 w-full" id="main-content-layout">
        <AnimatePresence mode="wait">
          {/* Main Home Screen: Countries + Universities */}
          {activeTab === "home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {/* Agency Welcome Letter & Credentials Stats Block */}
              <div className="max-w-7xl mx-auto px-4 mt-8" id="agency-intro-letter">
                <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0 text-left">
                  {/* Left Column: Welcome Letter */}
                  <div className="p-8 lg:p-10 lg:col-span-7 flex flex-col justify-between">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full text-indigo-700 text-[10px] font-bold uppercase tracking-wider mb-4">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Authorized Pathway Agency
                      </div>
                      
                      <h1 className="text-3xl font-black text-gray-950 tracking-tight leading-tight">
                        {branding.welcomeTitle || "Empowering Next-Gen Scholars Across Prestigious Global Borders"}
                      </h1>
                      
                      <div className="text-gray-600 text-xs font-semibold space-y-4 mt-5 leading-relaxed">
                        <p className="whitespace-pre-wrap">
                          {branding.welcomeLetter || "Welcome to GlobalEdu Consultancy, your accredited pathway partner to premier world-class universities and fully funded scholarship projects. Since 2011, our specialized agency of international advisors has worked to eliminate the complex obstacles of enrollment, document attestation, and study permit compliance. We take pride in mentoring high-potential candidates to secure admits, fellowship awards, and visa clearances across Europe, the UK, the US, and Canada. Select and explore your prospective academic gateways below to coordinate with our designated Admissions Portal."}
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-8 pt-6 border-t border-gray-150 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-black tracking-widest text-gray-400 block">Admissions Board</span>
                        <span className="text-xs font-black text-gray-800">{branding.name || "GlobalEdu Team"}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] uppercase font-black tracking-widest text-gray-400 block">Contact Desk</span>
                        <a href={`mailto:${branding.emailContact}`} className="text-xs font-bold text-indigo-650 hover:underline">
                          {branding.emailContact}
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Visual Stats Grid */}
                  <div className="bg-slate-50/50 p-8 lg:p-10 lg:col-span-5 border-t lg:border-t-0 lg:border-l border-gray-150 flex flex-col justify-center">
                    <div className="mb-6">
                      <span className="text-[10px] font-extrabold tracking-widest text-gray-400 uppercase">Current Performance Registry</span>
                      <h3 className="text-lg font-black text-gray-900 mt-0.5">Our Global Pedigree</h3>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {/* Stat 1 */}
                      <div className="bg-white p-4.5 rounded-2xl border border-gray-150 shadow-xs text-left">
                        <span className="block text-2xl font-black tracking-tight text-indigo-650">
                          {branding.statsStudents || "14,200+"}
                        </span>
                        <span className="text-[10px] font-bold text-gray-500 block mt-1 leading-snug">
                          Ambitious Scholars Dispatched
                        </span>
                      </div>

                      {/* Stat 2 */}
                      <div className="bg-white p-4.5 rounded-2xl border border-gray-150 shadow-xs text-left">
                        <span className="block text-2xl font-black tracking-tight text-indigo-650">
                          {branding.statsUniversities || "220+"}
                        </span>
                        <span className="text-[10px] font-bold text-gray-500 block mt-1 leading-snug">
                          Partner Universities
                        </span>
                      </div>

                      {/* Stat 3 */}
                      <div className="bg-white p-4.5 rounded-2xl border border-gray-150 shadow-xs text-left">
                        <span className="block text-xl font-black tracking-tight text-indigo-650 truncate" title={branding.statsScholarships}>
                          {branding.statsScholarships || "$46M+"}
                        </span>
                        <span className="text-[10px] font-bold text-gray-500 block mt-1 leading-snug">
                          Academic Funding Secured
                        </span>
                      </div>

                      {/* Stat 4 */}
                      <div className="bg-white p-4.5 rounded-2xl border border-gray-150 shadow-xs text-left">
                        <span className="block text-2xl font-black tracking-tight text-indigo-650">
                          {branding.statsVisaRate || "99.4%"}
                        </span>
                        <span className="text-[10px] font-bold text-gray-500 block mt-1 leading-snug">
                          Consular Approval Success
                        </span>
                      </div>
                    </div>

                    <div className="bg-indigo-50/50 p-3.5 rounded-xl border border-indigo-100 mt-5 text-[10px] font-bold text-indigo-850 leading-relaxed text-left">
                      💡 <strong>Live Calibration:</strong> In your Admin Suite tab, select the <em>Branding</em> sub-tab to edit this introduction letter, heading, and these metrics instantly.
                    </div>
                  </div>
                </div>
              </div>

              {/* Country grid banner */}
              <CountrySection
                countries={countries}
                user={currentUser}
                selectedCountryId={selectedCountryId}
                onSelectCountry={setSelectedCountryId}
                onAddCountry={handleAddCountry}
                onUpdateCountry={handleUpdateCountry}
                onDeleteCountry={handleDeleteCountry}
              />

              {/* Universities listing matching selected country */}
              <UniversitySection
                universities={universities}
                countries={countries}
                selectedCountryId={selectedCountryId}
                user={currentUser}
                onApply={handleInitiatingApply}
                onAddUniversity={handleAddUniversity}
                onUpdateUniversity={handleUpdateUniversity}
                onDeleteUniversity={handleDeleteUniversity}
              />

              {/* Country Universities Modal View overlay when a country is selected */}
              {selectedCountryId && (
                (() => {
                  const sCountry = countries.find((c) => c.id === selectedCountryId);
                  return sCountry ? (
                    <CountryUniversitiesModal
                      country={sCountry}
                      universities={universities}
                      onClose={() => setSelectedCountryId(null)}
                      onApply={(uni) => {
                        handleInitiatingApply(uni);
                      }}
                    />
                  ) : null;
                })()
              )}
            </motion.div>
          )}

          {/* Scholarships Opportunities Screen */}
          {activeTab === "scholarships" && (
            <motion.div
              key="scholarships"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
            >
              <ScholarshipSection
                universities={universities}
                countries={countries}
                scholarships={scholarships}
                onApply={handleInitiatingApply}
                user={currentUser}
                onUpdateUniversity={handleUpdateUniversity}
                onAddUniversity={handleAddUniversity}
                onDeleteUniversity={handleDeleteUniversity}
                onAddScholarship={handleAddScholarship}
                onUpdateScholarship={handleUpdateScholarship}
                onDeleteScholarship={handleDeleteScholarship}
              />
            </motion.div>
          )}

          {/* About Us Screen: Staff grids */}
          {activeTab === "about" && (
            <motion.div
              key="about"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AboutUs
                staff={staff}
                user={currentUser}
                onAddStaff={handleAddStaff}
                onUpdateStaff={handleUpdateStaff}
                onDeleteStaff={handleDeleteStaff}
                branding={branding}
              />
            </motion.div>
          )}

          {/* Authentication Panel (Sign In & Sign Up) */}
          {activeTab === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="py-12 px-4 max-w-md mx-auto"
              id="auth-routing-container"
            >
              {pendingApprovalUser ? (
                /* WAITING FOR ADMIN APPROVAL SCREEN */
                <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-xl text-center space-y-6">
                  <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center text-amber-600 mx-auto border border-amber-200">
                    <RefreshCw className="w-8 h-8 animate-spin text-amber-500" />
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-[10px] font-black tracking-widest text-amber-600 bg-amber-50 border border-amber-100 px-3 py-1 rounded-full uppercase">
                      Waiting for Admin Approval
                    </span>
                    <h3 className="text-xl font-black text-gray-950 tracking-tight pt-1">
                      Platform Application Pending
                    </h3>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      Thank you, <strong>{pendingApprovalUser.name}</strong>! Your registration request (<em>{pendingApprovalUser.email}</em>) for the <strong className="text-indigo-650 uppercase">{pendingApprovalUser.role}</strong> role has been securely filed.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 border border-gray-150 rounded-2xl text-[11px] leading-relaxed text-gray-600 text-left space-y-2">
                    <p className="font-bold text-gray-800">📌 Verifying your credentials:</p>
                    <div>• Registered Students and Agents require a validation check prior gateway login.</div>
                    <div>• Once approved, you can access your dashboard right away.</div>
                    <div>• Support coordinate hotline: <strong className="text-indigo-650">{branding.emailContact}</strong>.</div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await fetch("/api/db");
                          if (res.ok) {
                            const db = await res.json();
                            const updatedUser = db.users.find((u: any) => u.email.toLowerCase() === pendingApprovalUser.email.toLowerCase());
                            if (updatedUser) {
                              if (updatedUser.status === "approved") {
                                setCurrentUser(updatedUser);
                                setPendingApprovalUser(null);
                                alert(`Your credentials have been verified by the Administrator! Proceeding to your panel.`);
                                if (updatedUser.role === "admin") setActiveTab("admin-panel");
                                else if (updatedUser.role === "agent") setActiveTab("agent-panel");
                                else setActiveTab("student-panel");
                              } else {
                                alert(`Verification is still in pending status. Please wait for an administrator to approve your account.`);
                              }
                            }
                          }
                        } catch (err) {
                          console.error(err);
                        }
                      }}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 font-extrabold text-white text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Re-Check Verification Status
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setPendingApprovalUser(null);
                        setIsRegisterMode(false);
                        setAuthError("");
                      }}
                      className="text-xs text-indigo-650 font-bold hover:underline block pt-2 mx-auto"
                    >
                      ← Back to Login Gates
                    </button>
                  </div>
                </div>
              ) : (
                /* STANDARD 3-ROLE AUTHENTICATION CARD */
                <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-xl text-left space-y-6">
                  <div className="text-center">
                    {branding.logoUrl ? (
                      <div className="flex justify-center mb-3">
                        <img
                          src={branding.logoUrl}
                          alt={branding.name}
                          className="h-16 w-auto object-contain rounded-2xl border border-gray-100"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ) : (
                      <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-extrabold mx-auto shadow-md mb-3">
                        {branding.logoText || "FTZ"}
                      </div>
                    )}
                    <h2 className="text-2xl font-black text-gray-950 tracking-tight">
                      {isRegisterMode ? "Create Platform Identity" : "Verify Registrar Credentials"}
                    </h2>
                    <p className="text-xs text-gray-400 mt-1">
                      {isRegisterMode ? "Register student or agent portfolios" : "Access your assigned portal dashboard"}
                    </p>
                  </div>

                  {/* 3-Role login switcher tabs */}
                  {!isRegisterMode && (
                    <div className="bg-slate-50 p-1 rounded-xl grid grid-cols-3 gap-1">
                      <button
                        type="button"
                        onClick={() => { setLoginViewRole("student"); setAuthError(""); }}
                        className={`py-1.5 rounded-lg text-[10px] font-extrabold tracking-wide uppercase transition-all ${
                          loginViewRole === "student"
                            ? "bg-white text-indigo-700 shadow-sm border border-gray-100"
                            : "text-gray-400 hover:text-gray-700"
                        }`}
                      >
                        Student
                      </button>
                      <button
                        type="button"
                        onClick={() => { setLoginViewRole("agent"); setAuthError(""); }}
                        className={`py-1.5 rounded-lg text-[10px] font-extrabold tracking-wide uppercase transition-all ${
                          loginViewRole === "agent"
                            ? "bg-white text-indigo-700 shadow-sm border border-gray-100"
                            : "text-gray-400 hover:text-gray-700"
                        }`}
                      >
                        Agent
                      </button>
                      <button
                        type="button"
                        onClick={() => { setLoginViewRole("admin"); setAuthError(""); }}
                        className={`py-1.5 rounded-lg text-[10px] font-extrabold tracking-wide uppercase transition-all ${
                          loginViewRole === "admin"
                            ? "bg-white text-indigo-700 shadow-sm border border-gray-100"
                            : "text-gray-400 hover:text-gray-700"
                        }`}
                      >
                        Admin
                      </button>
                    </div>
                  )}

                  {authError && (
                    <div className="bg-red-50 border border-red-200 p-3.5 rounded-xl text-xs text-red-650 font-semibold flex items-center gap-1.5 animate-bounce">
                      <AlertIcon className="w-4.5 h-4.5 shrink-0" />
                      <span>{authError}</span>
                    </div>
                  )}

                  {/* Operational Gatekeeper Callouts */}
                  {!isRegisterMode && loginViewRole === "student" && systemSettings.disableStudentLogin && (
                    <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-2xl text-xs text-amber-850 leading-normal font-semibold flex items-start gap-2.5">
                      <AlertIcon className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <span className="font-extrabold block">Student Login Services Suspended</span>
                        <span className="block text-[10px] text-amber-700 font-medium mt-0.5 leading-relaxed">
                          The student portfolio is temporarily closed for catalog maintenance. Existing credentials are locked.
                        </span>
                      </div>
                    </div>
                  )}

                  {!isRegisterMode && loginViewRole === "agent" && systemSettings.disableAgentLogin && (
                    <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-2xl text-xs text-amber-850 leading-normal font-semibold flex items-start gap-2.5">
                      <AlertIcon className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <span className="font-extrabold block">Agent Workspace Offline</span>
                        <span className="block text-[10px] text-amber-700 font-medium mt-0.5 leading-relaxed">
                          Admissions Advisor login is currently closed by the administration.
                        </span>
                      </div>
                    </div>
                  )}

                  {isRegisterMode && authRoleReg === "student" && systemSettings.disableStudentRegister && (
                    <div className="bg-rose-50 border border-rose-250 p-3.5 rounded-2xl text-xs text-rose-850 leading-normal font-semibold flex items-start gap-2.5">
                      <AlertIcon className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <span className="font-extrabold block">Student Sign-Up Suspended</span>
                        <span className="block text-[10px] text-rose-700 font-medium mt-0.5 leading-relaxed">
                          New student registrations are deactivated.
                        </span>
                      </div>
                    </div>
                  )}

                  {isRegisterMode && authRoleReg === "agent" && systemSettings.disableAgentRegister && (
                    <div className="bg-rose-50 border border-rose-250 p-3.5 rounded-2xl text-xs text-rose-850 leading-normal font-semibold flex items-start gap-2.5">
                      <AlertIcon className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-extrabold block">Agent Registration Queue Shut</span>
                        <span className="block text-[10px] text-rose-700 font-medium mt-0.5 leading-relaxed">
                          Counselor on-boarding requests are disabled temporarily. See manual support desks.
                        </span>
                      </div>
                    </div>
                  )}

                   {/* Credentials Help Block */}
                  {!isRegisterMode && loginViewRole === "student" && (
                    <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-100 text-[10px] leading-relaxed text-amber-900 font-medium whitespace-pre-line">
                      <span className="font-bold flex items-center gap-1 mb-1">
                        🔑 Student Access:
                      </span>
                      {"• Please register a fresh account to get started.\n• Wait for an administrator to approve your registration request."}
                    </div>
                  )}

                  <form onSubmit={isRegisterMode ? handleRegisterSubmit : handleLoginSubmit} className="space-y-4">
                    {isRegisterMode && (
                      <div>
                        <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Your Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Catherine Reed"
                          value={authName}
                          onChange={(e) => setAuthName(e.target.value)}
                          className="w-full text-xs px-4 py-2.5 bg-gray-50/50 border border-gray-250 rounded-xl focus:outline-indigo-600"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Port Address / Email</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                        <input
                          type="email"
                          required
                          placeholder={
                            loginViewRole === "admin"
                              ? "ftz.edu.consultancy@gmail.com"
                              : loginViewRole === "agent"
                              ? "advisor.candidate@gmail.com"
                              : "student@gmail.com"
                          }
                          value={authEmail}
                          onChange={(e) => setAuthEmail(e.target.value)}
                          className="w-full text-xs pl-9 pr-4 py-2.5 bg-gray-50/50 border border-gray-250 rounded-xl focus:outline-indigo-600"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Security Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                        <input
                          type="password"
                          required
                          placeholder="••••••••"
                          value={authPassword}
                          onChange={(e) => setAuthPassword(e.target.value)}
                          className="w-full text-xs pl-9 pr-4 py-2.5 bg-gray-50/50 border border-gray-250 rounded-xl focus:outline-indigo-600"
                        />
                      </div>
                    </div>

                    {isRegisterMode && (
                      <div>
                        <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Select requested Account Role</label>
                        <div className="grid grid-cols-2 gap-2 mt-1">
                          <button
                            type="button"
                            onClick={() => setAuthRoleReg("student")}
                            className={`py-2 text-xs font-bold border rounded-xl transition-all ${
                              authRoleReg === "student"
                                ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                                : "border-gray-200 hover:bg-gray-50"
                            }`}
                          >
                            Student Apply Portal
                          </button>
                          <button
                            type="button"
                            onClick={() => setAuthRoleReg("agent")}
                            className={`py-2 text-xs font-bold border rounded-xl transition-all ${
                              authRoleReg === "agent"
                                ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                                : "border-gray-200 hover:bg-gray-50"
                            }`}
                          >
                            Admissions Agent Case
                          </button>
                        </div>
                        <span className="text-[10px] text-gray-400 block mt-1.5">Note: Registries wait in approval queue prior login verification.</span>
                      </div>
                    )}

                    {isRegisterMode && authRoleReg === "agent" && (
                      <div className="bg-slate-50/80 p-3.5 rounded-2xl border border-gray-200 space-y-2">
                        <label className="block text-[10px] font-extrabold text-slate-850 uppercase tracking-wider">
                          Countries you want to work on *
                        </label>
                        <p className="text-[9px] text-gray-450 leading-relaxed">
                          You will be restricted to view only student applications applying within these selected country boundaries. Select all that apply:
                        </p>
                        <div className="grid grid-cols-2 gap-1.5 mt-1">
                          {countries.map((c) => {
                            const isChecked = authAgentCountries.includes(c.id);
                            return (
                              <button
                                type="button"
                                key={c.id}
                                onClick={() => {
                                  if (isChecked) {
                                    setAuthAgentCountries(authAgentCountries.filter((id) => id !== c.id));
                                  } else {
                                    setAuthAgentCountries([...authAgentCountries, c.id]);
                                  }
                                }}
                                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all text-left ${
                                  isChecked
                                    ? "bg-indigo-50 border-indigo-300 text-indigo-900 shadow-sm"
                                    : "bg-white border-gray-250 text-gray-700 hover:bg-slate-50"
                                }`}
                              >
                                <span className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] font-black ${
                                  isChecked ? "bg-indigo-600 text-white border-indigo-650" : "bg-white border-gray-300"
                                }`}>
                                  {isChecked && "✓"}
                                </span>
                                <span className="truncate">{c.name}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {(() => {
                      const isStudentLoginDisabled = !isRegisterMode && loginViewRole === "student" && systemSettings.disableStudentLogin;
                      const isAgentLoginDisabled = !isRegisterMode && loginViewRole === "agent" && systemSettings.disableAgentLogin;
                      const isStudentRegisterDisabled = isRegisterMode && authRoleReg === "student" && systemSettings.disableStudentRegister;
                      const isAgentRegisterDisabled = isRegisterMode && authRoleReg === "agent" && systemSettings.disableAgentRegister;

                      const isDisabled = isStudentLoginDisabled || isAgentLoginDisabled || isStudentRegisterDisabled || isAgentRegisterDisabled;

                      let btnText = isRegisterMode ? "Submit Registration Request" : "Identify Account Access";
                      if (isStudentLoginDisabled) btnText = "Student Login Deactivated";
                      else if (isAgentLoginDisabled) btnText = "Agent Login Deactivated";
                      else if (isStudentRegisterDisabled) btnText = "Student Signup Closed";
                      else if (isAgentRegisterDisabled) btnText = "Agent Signup Closed";

                      return (
                        <button
                          type="submit"
                          disabled={isDisabled}
                          className={`w-full py-2.5 text-center text-xs font-extrabold text-white transition-colors rounded-xl shadow-md ${
                            isDisabled
                              ? "bg-gray-400 cursor-not-allowed opacity-75"
                              : "bg-indigo-600 hover:bg-indigo-700 cursor-pointer"
                          }`}
                        >
                          {btnText}
                        </button>
                      );
                    })()}
                  </form>



                  {/* Toggle sign-in vs sign-up mode (disabled if admin role tab is open) */}
                  {loginViewRole !== "admin" && (
                    <div className="text-center pt-2 border-t border-gray-100 text-xs font-semibold">
                      {isRegisterMode ? (
                        <p className="text-gray-500">
                          Already registered?{" "}
                          <button
                            type="button"
                            onClick={() => {
                              setIsRegisterMode(false);
                              setAuthError("");
                            }}
                            className="text-indigo-600 hover:underline"
                          >
                            Sign In Details
                          </button>
                        </p>
                      ) : (
                        <div>
                          {loginViewRole === "student" && systemSettings.disableStudentRegister ? (
                            <p className="text-gray-400 italic font-mono text-[10px]">⚠️ Student signup registry is temporarily offline.</p>
                          ) : loginViewRole === "agent" && systemSettings.disableAgentRegister ? (
                            <p className="text-gray-400 italic font-mono text-[10px]">⚠️ Advisor signup registry is temporarily offline.</p>
                          ) : (
                            <p className="text-gray-500">
                              New to consultancy?{" "}
                              <button
                                type="button"
                                onClick={() => {
                                  setIsRegisterMode(true);
                                  setAuthError("");
                                  setAuthRoleReg(loginViewRole === "agent" ? "agent" : "student");
                                }}
                                className="text-indigo-600 hover:underline"
                              >
                                Create {loginViewRole === "agent" ? "Agent" : "Student"} Request
                              </button>
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* Admin Panel Route */}
          {activeTab === "admin-panel" && currentUser?.role === "admin" && (
            <motion.div
              key="admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AdminPanel
                user={currentUser}
                users={users}
                applications={applications}
                countries={countries}
                universities={universities}
                branding={branding}
                storageConfig={storageConfig}
                systemSettings={systemSettings}
                scholarships={scholarships}
                onApproveUser={handleApproveUser}
                onUpdateUserCredentials={handleUpdateUserCredentials}
                onDeleteUser={handleDeleteUser}
                onUpdateBranding={handleUpdateBranding}
                onUpdateStorage={handleUpdateStorage}
                onUpdateApplicationStatus={handleUpdateApplicationStatus}
                onDeleteApplication={handleDeleteApplication}
                onAddCountry={handleAddCountry}
                onUpdateCountry={handleUpdateCountry}
                onDeleteCountry={handleDeleteCountry}
                onAddUniversity={handleAddUniversity}
                onUpdateUniversity={handleUpdateUniversity}
                onDeleteUniversity={handleDeleteUniversity}
                onUpdateSystemSettings={handleUpdateSystemSettings}
                onAddScholarship={handleAddScholarship}
                onUpdateScholarship={handleUpdateScholarship}
                onDeleteScholarship={handleDeleteScholarship}
                socket={socket}
                onlineUserIds={onlineUserIds}
              />
            </motion.div>
          )}

          {/* Agent Panel Route */}
          {activeTab === "agent-panel" && currentUser?.role === "agent" && (
            <motion.div
              key="agent"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AgentPanel
                user={currentUser}
                applications={applications}
                countries={countries}
                onUpdateApplicationStatus={handleUpdateApplicationStatus}
                onOpenChat={() => setShowGlobalMessenger(true)}
              />
            </motion.div>
          )}

          {/* Student Panel Route */}
          {activeTab === "student-panel" && currentUser?.role === "student" && (
            <motion.div
              key="student"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <StudentPanel
                user={currentUser}
                applications={applications}
                onUploadProfilePhoto={handleUploadProfilePhoto}
                setActiveTab={setActiveTab}
                onOpenChat={() => setShowGlobalMessenger(true)}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Branded component */}
      <footer className="bg-slate-900 text-white mt-12 py-8 border-t border-slate-800 text-left" id="app-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 text-white font-extrabold text-lg">
              {branding.logoUrl ? (
                <img
                  src={branding.logoUrl}
                  alt={branding.name}
                  className="w-10 h-10 object-contain rounded-lg border border-slate-800"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-xs">{branding.logoText || "FTZ"}</span>
              )}
              <span>{branding.name || "FTZ EDU CONSULTANCY"}</span>
            </div>
            <p className="text-[11px] text-gray-400 mt-2.5 max-w-sm leading-relaxed">
              Serving global scholar networks with integrity. Bridging premier research college credentials through unified admission management pipelines.
            </p>
          </div>

          <div className="space-y-1 text-xs">
            <span className="text-[10px] text-gray-400 uppercase tracking-widest font-black block mb-2">Agency Contacts</span>
            <div className="text-gray-300">Admission desk: {branding.emailContact}</div>
            {branding.emailContact2 && (
              <div className="text-gray-300">Alternate support: {branding.emailContact2}</div>
            )}
            <div className="text-gray-300">Hotline advisory: +1 (800) 545-EDUK</div>
            <div className="text-gray-300">Google Vault storage secure destination configuration link active.</div>
          </div>

          <div className="space-y-1 text-xs text-gray-400">
            <span className="text-[10px] text-gray-400 uppercase tracking-widest font-black block mb-2">Legal Compliance</span>
            <p className="leading-relaxed text-[10px]">
              Platform conforms standard encryption, ISO registration audits, GDPR data privacy, and zero-trust attribute access policies securely.
            </p>
            <p className="pt-2 text-[9px] text-gray-500">© 2026 {branding.name}. All Rights Reservable.</p>
          </div>
        </div>
      </footer>

      {/* Target Applying University form popup modal */}
      {applyingUniversity && (
        <ApplicationModal
          university={applyingUniversity}
          user={currentUser}
          onClose={() => setApplyingUniversity(null)}
          onSubmit={handleApplicationSubmit}
          storageDestination={storageConfig.destinationLink}
        />
      )}

      {/* Global Messenger Panel Flyout / Overlay Modal */}
      <AnimatePresence>
        {showGlobalMessenger && currentUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4"
            id="global-messenger-backdrop"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="w-full max-w-5xl h-[720px] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden relative"
              id="global-messenger-window"
            >
              <div className="absolute top-4 right-4 z-10 sm:hidden">
                <button
                  onClick={() => setShowGlobalMessenger(false)}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-gray-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <Messenger
                currentUser={currentUser}
                onClose={() => setShowGlobalMessenger(false)}
                socket={socket}
                onlineUserIds={onlineUserIds}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Floating Chat Bubble widget for quick coordination */}
      {currentUser && currentUser.status === "approved" && !showGlobalMessenger && (
        <button
          onClick={() => setShowGlobalMessenger(true)}
          className="fixed bottom-6 right-6 p-4 bg-indigo-600 hover:bg-indigo-750 text-white rounded-2xl shadow-xl hover:shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer z-40 flex items-center gap-2 group border border-indigo-500"
          title="Open Portal Chat Coordination"
          id="floating-portal-chat-bubble"
        >
          <MessagesSquare className="w-6 h-6 animate-pulse" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-out text-xs font-extrabold uppercase tracking-wider block">
            Portal Messenger
          </span>
          {unreadChatCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-md animate-bounce">
              {unreadChatCount}
            </span>
          )}
        </button>
      )}
    </div>
  );
}
