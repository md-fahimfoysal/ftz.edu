import React, { useState, useEffect } from "react";
import { User, Application, Branding, StorageConfig, Country, University, SystemSettings, GlobalScholarship } from "../types";
import { Check, X, Shield, Users, Compass, FolderKanban, Settings, Award, Trash2, Edit3, Globe, Save, CheckCircle, AlertCircle, RefreshCw, Plus, Lock, Eye, EyeOff, Image as ImageIcon, CheckCheck, Calendar, Clock, MessageSquare } from "lucide-react";
import { getCountdown, formatDate } from "./UniversitySection";
import Messenger from "./Messenger";

interface AdminPanelProps {
  user: User;
  users: User[];
  applications: Application[];
  countries: Country[];
  universities: University[];
  branding: Branding;
  storageConfig: StorageConfig;
  systemSettings: SystemSettings;
  scholarships?: GlobalScholarship[];
  onApproveUser: (id: string) => Promise<void>;
  onUpdateUserCredentials: (id: string, updated: Partial<User>) => Promise<void>;
  onDeleteUser: (id: string) => Promise<void>;
  onUpdateBranding: (updated: Partial<Branding>) => Promise<void>;
  onUpdateStorage: (updated: Partial<StorageConfig>) => Promise<void>;
  onUpdateApplicationStatus: (id: string, status: string, notes: string, screenshot?: string) => Promise<void>;
  onAddCountry: (newCountry: Omit<Country, "id">) => Promise<void>;
  onUpdateCountry: (id: string, updated: Partial<Country>) => Promise<void>;
  onDeleteCountry: (id: string) => Promise<void>;
  onAddUniversity: (newUni: Omit<University, "id">) => Promise<void>;
  onUpdateUniversity: (id: string, updated: Partial<University>) => Promise<void>;
  onDeleteUniversity: (id: string) => Promise<void>;
  onDeleteApplication?: (id: string) => Promise<void>;
  onUpdateSystemSettings: (updated: Partial<SystemSettings>) => Promise<void>;
  onAddScholarship?: (newSch: Omit<GlobalScholarship, "id">) => Promise<void>;
  onUpdateScholarship?: (id: string, updated: Partial<GlobalScholarship>) => Promise<void>;
  onDeleteScholarship?: (id: string) => Promise<void>;
  socket?: WebSocket | null;
  onlineUserIds?: string[];
}

export default function AdminPanel({
  user,
  users,
  applications,
  countries,
  universities,
  branding,
  storageConfig,
  systemSettings,
  scholarships = [],
  onApproveUser,
  onUpdateUserCredentials,
  onDeleteUser,
  onUpdateBranding,
  onUpdateStorage,
  onUpdateApplicationStatus,
  onDeleteApplication,
  onAddCountry,
  onUpdateCountry,
  onDeleteCountry,
  onAddUniversity,
  onUpdateUniversity,
  onDeleteUniversity,
  onUpdateSystemSettings,
  onAddScholarship,
  onUpdateScholarship,
  onDeleteScholarship,
  socket = null,
  onlineUserIds = [],
}: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<"users" | "pipelines" | "branding" | "storage" | "academics" | "system-settings" | "messages">("users");

  // Custom Delete Confirm state
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    type: "country" | "university" | "scholarship";
    name?: string;
  } | null>(null);

  const handleConfirmDelete = async () => {
    if (!deleteConfirm) return;
    const { id, type } = deleteConfirm;
    
    // Close modal first to prevent React rendering race conditions
    setDeleteConfirm(null);
    
    try {
      if (type === "country") {
        await onDeleteCountry(id);
      } else if (type === "university") {
        await onDeleteUniversity(id);
      } else if (type === "scholarship") {
        const u = universities.find((uni) => uni.id === id);
        if (u) {
          await onUpdateUniversity(u.id, {
            ...u,
            scholarship: null as any,
          });
        }
      }
    } catch (err) {
      console.error("Delete failed", err);
    }
  };

  // User Credentials management states
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editingUserEmail, setEditingUserEmail] = useState("");
  const [editingUserPassword, setEditingUserPassword] = useState("");
  const [editingUserName, setEditingUserName] = useState("");
  const [editingUserRole, setEditingUserRole] = useState<'admin' | 'agent' | 'student'>("student");
  const [editingUserStatus, setEditingUserStatus] = useState<'pending' | 'approved'>("approved");
  const [isCredentialModalOpen, setIsCredentialModalOpen] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  // Local Brand form state
  const [brandName, setBrandName] = useState(branding.name);
  const [brandLogo, setBrandLogo] = useState(branding.logoText);
  const [brandEmail, setBrandEmail] = useState(branding.emailContact);
  const [brandEmail2, setBrandEmail2] = useState(branding.emailContact2 || "");
  const [brandLogoUrl, setBrandLogoUrl] = useState(branding.logoUrl || "");
  const [welcomeTitle, setWelcomeTitle] = useState(branding.welcomeTitle || "Empowering Next-Gen Scholars Across Prestigious Global Borders");
  const [welcomeLetter, setWelcomeLetter] = useState(branding.welcomeLetter || "");
  const [statsStudents, setStatsStudents] = useState(branding.statsStudents || "14,200+");
  const [statsUniversities, setStatsUniversities] = useState(branding.statsUniversities || "220+");
  const [statsScholarships, setStatsScholarships] = useState(branding.statsScholarships || "$46,000,000+");
  const [statsVisaRate, setStatsVisaRate] = useState(branding.statsVisaRate || "99.4+");
  const [isSavingBranding, setIsSavingBranding] = useState(false);

  // Storage form state
  const [storeLink, setStoreLink] = useState(storageConfig.destinationLink);
  const [storeProvider, setStoreProvider] = useState(storageConfig.provider);
  const [isSavingStorage, setIsSavingStorage] = useState(false);

  useEffect(() => {
    setBrandName(branding.name);
    setBrandLogo(branding.logoText);
    setBrandEmail(branding.emailContact);
    setBrandEmail2(branding.emailContact2 || "");
    setBrandLogoUrl(branding.logoUrl || "");
    setWelcomeTitle(branding.welcomeTitle || "Empowering Next-Gen Scholars Across Prestigious Global Borders");
    setWelcomeLetter(branding.welcomeLetter || "");
    setStatsStudents(branding.statsStudents || "14,200+");
    setStatsUniversities(branding.statsUniversities || "220+");
    setStatsScholarships(branding.statsScholarships || "$46,000,000+");
    setStatsVisaRate(branding.statsVisaRate || "99.4+");
  }, [branding]);

  useEffect(() => {
    setStoreLink(storageConfig.destinationLink);
    setStoreProvider(storageConfig.provider);
  }, [storageConfig]);

  // Local Academic Directory manager states
  const [activeAcademicsSubTab, setActiveAcademicsSubTab] = useState<"countries" | "universities" | "scholarships">("countries");

  // Country manager states
  const [isAddingCountry, setIsAddingCountry] = useState(false);
  const [editingCountryId, setEditingCountryId] = useState<string | null>(null);
  const [countryName, setCountryName] = useState("");
  const [countryDescription, setCountryDescription] = useState("");
  const [countryImageUrl, setCountryImageUrl] = useState("");

  // University manager states
  const [isAddingUniversity, setIsAddingUniversity] = useState(false);
  const [editingUniversityId, setEditingUniversityId] = useState<string | null>(null);
  const [uniName, setUniName] = useState("");
  const [uniCountryId, setUniCountryId] = useState("");
  const [uniImageUrl, setUniImageUrl] = useState("");
  const [uniPrograms, setUniPrograms] = useState("");
  const [uniSubjects, setUniSubjects] = useState("");
  const [uniSchTitle, setUniSchTitle] = useState("");
  const [uniSchDesc, setUniSchDesc] = useState("");
  const [uniSchAmount, setUniSchAmount] = useState("");
  const [uniSchFully, setUniSchFully] = useState(false);
  const [uniSummerDeadline, setUniSummerDeadline] = useState("");
  const [uniFallDeadline, setUniFallDeadline] = useState("");
  const [uniAdminComment, setUniAdminComment] = useState("");

  // Scholarship manager states
  const [isAddingSch, setIsAddingSch] = useState(false);
  const [selectedSchUniId, setSelectedSchUniId] = useState("");
  const [schTitle, setSchTitle] = useState("");
  const [schDescription, setSchDescription] = useState("");
  const [schAmount, setSchAmount] = useState("");
  const [schFully, setSchFully] = useState(false);
  const [editingSchUniId, setEditingSchUniId] = useState<string | null>(null);
  const [schSummerDeadline, setSchSummerDeadline] = useState("");
  const [schFallDeadline, setSchFallDeadline] = useState("");
  const [schAdminComment, setSchAdminComment] = useState("");

  // User Filtering and Editing States
  const [userRoleFilter, setUserRoleFilter] = useState<"student" | "agent" | "admin">("student");
  const [editingUserCountries, setEditingUserCountries] = useState<string[]>([]);
  const [editingUserStudentId, setEditingUserStudentId] = useState("");

  // Document verification states
  const [verifiedDocs, setVerifiedDocs] = useState<Record<string, 'checking' | 'active' | 'error'>>({});

  // --- Actions ---
  const handleOpenCredentialModal = (u: User) => {
    setEditingUserId(u.id);
    setEditingUserEmail(u.email);
    setEditingUserPassword(u.password || "");
    setEditingUserName(u.name);
    setEditingUserRole(u.role);
    setEditingUserStatus(u.status);
    setEditingUserCountries(u.countries || []);
    setEditingUserStudentId(u.studentId || "");
    setIsPasswordVisible(false);
    setIsCredentialModalOpen(true);
  };

  const handleSaveCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUserId) return;
    try {
      await onUpdateUserCredentials(editingUserId, {
        email: editingUserEmail,
        password: editingUserPassword,
        name: editingUserName,
        role: editingUserRole,
        status: editingUserStatus,
        countries: editingUserRole === "agent" ? editingUserCountries : undefined,
        studentId: editingUserRole === "student" ? editingUserStudentId.trim() : undefined,
      });
      setIsCredentialModalOpen(false);
      setEditingUserId(null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCountrySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!countryName.trim()) return;

    try {
      if (editingCountryId) {
        await onUpdateCountry(editingCountryId, {
          name: countryName,
          description: countryDescription,
          imageUrl: countryImageUrl,
        });
        alert("Country updated successfully!");
      } else {
        await onAddCountry({
          name: countryName,
          description: countryDescription,
          imageUrl: countryImageUrl || "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&q=80&w=800",
        });
        alert("Country added successfully!");
      }
      setIsAddingCountry(false);
      setEditingCountryId(null);
      setCountryName("");
      setCountryDescription("");
      setCountryImageUrl("");
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenEditCountry = (c: Country) => {
    setCountryName(c.name);
    setCountryDescription(c.description);
    setCountryImageUrl(c.imageUrl);
    setEditingCountryId(c.id);
    setIsAddingCountry(true);
  };

  const handleOpenAddCountry = () => {
    setCountryName("");
    setCountryDescription("");
    setCountryImageUrl("https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&q=80&w=800");
    setEditingCountryId(null);
    setIsAddingCountry(true);
  };

  const handleDeleteCountryClick = (cId: string, name: string) => {
    setDeleteConfirm({
      id: cId,
      type: "country",
      name,
    });
  };

  // University Actions
  const handleUniversitySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uniName.trim() || !uniCountryId) {
      alert("Please enter a name and select a country.");
      return;
    }

    const parsedPrograms = uniPrograms.split(",").map((p) => p.trim()).filter(Boolean);
    const parsedSubjects = uniSubjects.split(",").map((s) => s.trim()).filter(Boolean);

    const scholarshipData = uniSchTitle.trim() ? {
      title: uniSchTitle,
      description: uniSchDesc,
      amount: uniSchAmount,
      isFullyFunded: uniSchFully,
      summerDeadline: uniSummerDeadline || "",
      fallDeadline: uniFallDeadline || "",
      adminComment: uniAdminComment || "",
    } : undefined;

    const payload = {
      name: uniName,
      countryId: uniCountryId,
      imageUrl: uniImageUrl || "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800",
      programs: parsedPrograms.length ? parsedPrograms : ["Bachelor", "Master"],
      subjects: parsedSubjects.length ? parsedSubjects : ["Computer Science"],
      scholarship: scholarshipData,
      summerDeadline: uniSummerDeadline || "",
      fallDeadline: uniFallDeadline || "",
      adminComment: uniAdminComment || "",
    };

    try {
      if (editingUniversityId) {
        await onUpdateUniversity(editingUniversityId, payload);
        alert("University updated successfully!");
      } else {
        await onAddUniversity(payload);
        alert("University added successfully!");
      }
      setIsAddingUniversity(false);
      setEditingUniversityId(null);
      setUniName("");
      setUniCountryId("");
      setUniImageUrl("");
      setUniPrograms("");
      setUniSubjects("");
      setUniSchTitle("");
      setUniSchDesc("");
      setUniSchAmount("");
      setUniSchFully(false);
      setUniSummerDeadline("");
      setUniFallDeadline("");
      setUniAdminComment("");
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenEditUni = (u: University) => {
    setUniName(u.name);
    setUniCountryId(u.countryId);
    setUniImageUrl(u.imageUrl);
    setUniPrograms(u.programs.join(", "));
    setUniSubjects(u.subjects.join(", "));
    setUniSchTitle(u.scholarship?.title || "");
    setUniSchDesc(u.scholarship?.description || "");
    setUniSchAmount(u.scholarship?.amount || "");
    setUniSchFully(u.scholarship?.isFullyFunded || false);
    setUniSummerDeadline(u.summerDeadline || u.scholarship?.summerDeadline || "");
    setUniFallDeadline(u.fallDeadline || u.scholarship?.fallDeadline || "");
    setUniAdminComment(u.adminComment || u.scholarship?.adminComment || "");
    setEditingUniversityId(u.id);
    setIsAddingUniversity(true);
  };

  const handleOpenAddUni = () => {
    setUniName("");
    setUniCountryId(countries[0]?.id || "");
    setUniImageUrl("https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800");
    setUniPrograms("Bachelor, Master, PhD");
    setUniSubjects("Computer Science, Business Administration");
    setUniSchTitle("");
    setUniSchDesc("");
    setUniSchAmount("");
    setUniSchFully(false);
    setUniSummerDeadline("");
    setUniFallDeadline("");
    setUniAdminComment("");
    setEditingUniversityId(null);
    setIsAddingUniversity(true);
  };

  const handleDeleteUniClick = (uId: string, name: string) => {
    setDeleteConfirm({
      id: uId,
      type: "university",
      name,
    });
  };

  // Scholarship Actions
  const handleScholarshipSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const uniId = editingSchUniId || selectedSchUniId;
    if (!uniId) {
      alert("Please select a university.");
      return;
    }
    if (!schTitle.trim()) {
      alert("Please enter a scholarship title.");
      return;
    }

    const targetUni = universities.find((u) => u.id === uniId);
    if (!targetUni) return;

    const updatedScholarship = {
      title: schTitle,
      description: schDescription,
      amount: schAmount,
      isFullyFunded: schFully,
      summerDeadline: schSummerDeadline || "",
      fallDeadline: schFallDeadline || "",
      adminComment: schAdminComment || "",
    };

    try {
      await onUpdateUniversity(uniId, {
        ...targetUni,
        scholarship: updatedScholarship,
        summerDeadline: schSummerDeadline || "",
        fallDeadline: schFallDeadline || "",
        adminComment: schAdminComment || "",
      });

      alert(editingSchUniId ? "Scholarship details updated successfully!" : "Scholarship registered successfully!");
      setIsAddingSch(false);
      setSelectedSchUniId("");
      setEditingSchUniId(null);
      setSchTitle("");
      setSchDescription("");
      setSchAmount("");
      setSchFully(false);
      setSchSummerDeadline("");
      setSchFallDeadline("");
      setSchAdminComment("");
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenEditSch = (u: University) => {
    setSchTitle(u.scholarship?.title || "");
    setSchDescription(u.scholarship?.description || "");
    setSchAmount(u.scholarship?.amount || "");
    setSchFully(u.scholarship?.isFullyFunded || false);
    setSchSummerDeadline(u.scholarship?.summerDeadline || "");
    setSchFallDeadline(u.scholarship?.fallDeadline || "");
    setSchAdminComment(u.scholarship?.adminComment || "");
    setEditingSchUniId(u.id);
    setIsAddingSch(true);
  };

  const handleOpenAddSch = () => {
    setSchTitle("");
    setSchDescription("");
    setSchAmount("");
    setSchFully(false);
    setSchSummerDeadline("");
    setSchFallDeadline("");
    setSchAdminComment("");
    
    // Choose first university that doesn't currently contain a scholarship, if any
    const availableUnis = universities.filter((u) => !u.scholarship || !u.scholarship.title);
    setSelectedSchUniId(availableUnis[0]?.id || universities[0]?.id || "");
    setEditingSchUniId(null);
    setIsAddingSch(true);
  };

  const handleRemoveSchClick = (u: University) => {
    setDeleteConfirm({
      id: u.id,
      type: "scholarship",
      name: u.scholarship?.title || u.name,
    });
  };

  // Application Pipeline change state
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [newPipelineStatus, setNewPipelineStatus] = useState("");
  const [customAdminPipelineStatusText, setCustomAdminPipelineStatusText] = useState("");
  const [showAdminCustomInput, setShowAdminCustomInput] = useState(false);
  const [pipelineNote, setPipelineNote] = useState("");
  const [adminPortalScreenshot, setAdminPortalScreenshot] = useState("");

  const handleSaveBranding = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingBranding(true);
    try {
      await onUpdateBranding({
        name: brandName,
        logoText: brandLogo,
        logoUrl: brandLogoUrl || undefined,
        emailContact: brandEmail,
        emailContact2: brandEmail2 || undefined,
        welcomeTitle,
        welcomeLetter,
        statsStudents,
        statsUniversities,
        statsScholarships,
        statsVisaRate,
      });
      alert("Website Branding successfully saved!");
    } catch (err) {
      console.error(err);
    } finally {
      setIsSavingBranding(false);
    }
  };

  const handleSaveStorage = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingStorage(true);
    try {
      await onUpdateStorage({
        destinationLink: storeLink,
        provider: storeProvider
      });
      alert("Storage Configuration Updated!");
    } catch (err) {
      console.error(err);
    } finally {
      setIsSavingStorage(false);
    }
  };

  const handlePipelineStatusUpdate = async (appId: string) => {
    const finalStatus = newPipelineStatus === "Custom" ? customAdminPipelineStatusText.trim() : newPipelineStatus;
    if (!finalStatus) {
      alert("Please specify or choose a status stage!");
      return;
    }
    try {
      await onUpdateApplicationStatus(appId, finalStatus, pipelineNote, adminPortalScreenshot || undefined);
      setSelectedAppId(null);
      setPipelineNote("");
      setCustomAdminPipelineStatusText("");
      setShowAdminCustomInput(false);
      setAdminPortalScreenshot("");
      alert("Application status successfully updated!");
    } catch (err) {
      console.error(err);
    }
  };

  // Stats calculation
  const pendingUsers = users.filter((u) => u.status === "pending");
  const approvedUsers = users.filter((u) => u.status === "approved");
  const totalApps = applications.length;

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto" id="admin-panel-dashboard">
      <div className="text-left mb-8">
        <span className="text-xs font-bold uppercase text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full">
          Global Leadership Panel
        </span>
        <h1 className="text-3xl font-extrabold text-gray-950 mt-3 tracking-tight flex items-center gap-2">
          <Shield className="w-8 h-8 text-amber-550" /> Director Administration Portal
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Full audit controls for consultancy registries, active agent assignments, user approvals, and global storage links.
        </p>
      </div>

      {/* Grid of stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8" id="admin-stats-grid">
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase">Registry pending approvals</span>
          <div className="text-2xl font-extrabold text-amber-600 mt-1">{pendingUsers.length} Users</div>
          <p className="text-[10px] text-gray-500 mt-0.5">Students & agent requests</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase">Total Active Users</span>
          <div className="text-2xl font-extrabold text-indigo-900 mt-1">{approvedUsers.length} Advisors & Students</div>
          <p className="text-[10px] text-gray-500 mt-0.5">Approved platform accounts</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase">Applications Intake</span>
          <div className="text-2xl font-extrabold text-teal-600 mt-1">{totalApps} Files</div>
          <p className="text-[10px] text-gray-500 mt-0.5">Total university enrollments</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase">Countries Directory</span>
          <div className="text-2xl font-extrabold text-slate-800 mt-1">{countries.length} Global Hubs</div>
          <p className="text-[10px] text-gray-500 mt-0.5">{universities.length} Active university partners</p>
        </div>
      </div>

      {/* Sub Tabs block */}
      <div className="flex border-b border-gray-200 mb-6" id="admin-subtabs">
        <button
          onClick={() => setActiveSubTab("users")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "users"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
        >
          <span className="flex items-center gap-1.5"><Users className="w-4 h-4" /> Users Management ({pendingUsers.length} pending)</span>
        </button>
        <button
          onClick={() => setActiveSubTab("pipelines")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "pipelines"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
        >
          <span className="flex items-center gap-1.5"><FolderKanban className="w-4 h-4" /> Application Pipelines</span>
        </button>
        <button
          onClick={() => setActiveSubTab("branding")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "branding"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
        >
          <span className="flex items-center gap-1.5"><Settings className="w-4 h-4" /> Brand & Contact Defaults</span>
        </button>
        <button
          onClick={() => setActiveSubTab("storage")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "storage"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
        >
          <span className="flex items-center gap-1.5"><Compass className="w-4 h-4" /> Cloud Storage link</span>
        </button>
        <button
          onClick={() => setActiveSubTab("academics")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "academics"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
          id="admin-academics-btn"
        >
          <span className="flex items-center gap-1.5"><Award className="w-4 h-4 text-emerald-500" /> Academics & Scholarships</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab("system-settings")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "system-settings"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
          id="admin-system-settings-btn"
        >
          <span className="flex items-center gap-1.5"><Shield className="w-4 h-4 text-rose-500" /> Portal Access Control</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab("messages")}
          className={`pb-3 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeSubTab === "messages"
              ? "border-amber-500 text-amber-700"
              : "border-transparent text-gray-500 hover:text-gray-900"
          }`}
          id="admin-messages-tab-btn"
        >
          <span className="flex items-center gap-1.5"><MessageSquare className="w-4 h-4 text-indigo-500 animate-pulse" /> Messaging Desk</span>
        </button>
      </div>

      {/* Tab Panels content */}
      <div className="bg-white border border-gray-150 rounded-2xl p-6" id="admin-panel-views">
        
        {/* Real-time Messaging Desk view */}
        {activeSubTab === "messages" && (
          <div className="rounded-2xl overflow-hidden border border-gray-150 shadow-sm" id="admin-nested-messenger">
            <Messenger
              currentUser={user}
              socket={socket}
              onlineUserIds={onlineUserIds}
            />
          </div>
        )}

        {/* Users view */}
        {activeSubTab === "users" && (
          <div className="space-y-6 text-left" id="admin-users-panel">
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-gray-100 pb-4 gap-4">
              <div>
                <h3 className="text-lg font-extrabold text-gray-950 flex items-center gap-1.5">
                  Registries Verification & Account Moderation
                </h3>
                <p className="text-xs text-gray-400 mt-1">Manage, approve, and audit student registrations and advisor credentials independently.</p>
              </div>

              {/* Filter Pills */}
              <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200 self-start md:self-auto">
                <button
                  onClick={() => setUserRoleFilter("student")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    userRoleFilter === "student"
                      ? "bg-white text-indigo-750 shadow-sm"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                >
                  Student Registry ({users.filter(u => u.role === "student" && u.status === "pending").length} pending)
                </button>
                <button
                  onClick={() => setUserRoleFilter("agent")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    userRoleFilter === "agent"
                      ? "bg-white text-indigo-750 shadow-sm"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                >
                  Agent Advisor Registry ({users.filter(u => u.role === "agent" && u.status === "pending").length} pending)
                </button>
                <button
                  onClick={() => setUserRoleFilter("admin")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    userRoleFilter === "admin"
                      ? "bg-white text-indigo-750 shadow-sm"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                >
                  Admins
                </button>
              </div>
            </div>

            {/* A. STUDENT REGISTRY ACTION LEVEL */}
            {userRoleFilter === "student" && (
              <div className="space-y-8" id="student-registry-stage">
                {/* Section A.1: Pending Student Approval Requests */}
                <div className="bg-amber-50/40 rounded-2xl border border-amber-100 p-5">
                  <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" /> Pending Student Registration Approvals
                  </h4>
                  {users.filter(u => u.role === "student" && u.status === "pending").length === 0 ? (
                    <p className="text-xs text-amber-700 font-semibold italic">No pending student approval requests in the registry.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-amber-50 text-amber-900 font-bold uppercase border-b border-amber-200">
                            <th className="p-3">Student Name / Email</th>
                            <th className="p-3">Generated Student ID</th>
                            <th className="p-3">Signed up At</th>
                            <th className="p-3 text-right">Instant Validation Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {users.filter(u => u.role === "student" && u.status === "pending").map((u) => (
                            <tr key={u.id} className="border-b border-amber-100/50 hover:bg-amber-100/20">
                              <td className="p-3 flex items-center gap-2">
                                <img
                                  src={u.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"}
                                  alt={u.name}
                                  className="w-8 h-8 rounded-full object-cover border border-amber-100"
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <div className="font-extrabold text-amber-950">{u.name}</div>
                                  <div className="text-[10px] text-amber-700">{u.email}</div>
                                </div>
                              </td>
                              <td className="p-3">
                                <span className="font-mono text-xs font-black text-amber-850">{u.studentId || "Pending Assign"}</span>
                              </td>
                              <td className="p-3 text-amber-800 font-semibold">
                                {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "Demo"}
                              </td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => onApproveUser(u.id)}
                                  className="px-3 py-1 text-[10px] font-extrabold text-amber-900 bg-amber-100 border border-amber-300 rounded-lg hover:bg-amber-200 transition-colors"
                                >
                                  Approve Student Registration
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Section A.2: Approved active students list */}
                <div>
                  <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider mb-3">
                    Approved Student Registry Database
                  </h4>
                  {users.filter(u => u.role === "student" && u.status === "approved").length === 0 ? (
                    <p className="text-xs text-gray-500 italic">No approved student accounts registered on the platform.</p>
                  ) : (
                    <div className="overflow-x-auto bg-white rounded-2xl border border-gray-150">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-gray-50 text-gray-500 font-extrabold uppercase border-b border-gray-150">
                            <th className="p-3">Student profile / contact</th>
                            <th className="p-3">Auto-Generated Student ID</th>
                            <th className="p-3">Approved date</th>
                            <th className="p-3 text-right">Administrative Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {users.filter(u => u.role === "student" && u.status === "approved").map((u) => (
                            <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50/50">
                              <td className="p-3 flex items-center gap-2">
                                <img
                                  src={u.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"}
                                  alt={u.name}
                                  className="w-8 h-8 rounded-full object-cover border border-gray-100"
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <div className="font-extrabold text-gray-900">{u.name}</div>
                                  <div className="text-[10px] text-gray-500">{u.email}</div>
                                </div>
                              </td>
                              <td className="p-3">
                                <span className="inline-block px-2.5 py-1 text-[10px] font-mono font-black text-indigo-750 bg-indigo-50 border border-indigo-150 rounded-lg tracking-wider">
                                  {u.studentId || "STU-NONE"}
                                </span>
                              </td>
                              <td className="p-3 text-gray-500 font-bold">
                                {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "Demo"}
                              </td>
                              <td className="p-3 text-right">
                                <div className="inline-flex gap-1.5 justify-end">
                                  <button
                                    onClick={() => handleOpenCredentialModal(u)}
                                    className="px-2.5 py-1 text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors"
                                  >
                                    Edit Credentials & ID
                                  </button>
                                  {u.id !== user.id && (
                                    <button
                                      onClick={() => onDeleteUser(u.id)}
                                      className="p-1 px-2 border border-red-200 text-red-650 hover:bg-red-50 rounded-lg text-[10px] font-bold"
                                      title="Remove User Account"
                                    >
                                      Delete
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* B. AGENT ADVISOR REGISTRY ACTION LEVEL */}
            {userRoleFilter === "agent" && (
              <div className="space-y-8" id="agent-registry-stage">
                {/* Section B.1: Pending Agent Approval Requests */}
                <div className="bg-amber-50/40 rounded-2xl border border-amber-100 p-5">
                  <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" /> Pending Agent Advisor Access approvals
                  </h4>
                  {users.filter(u => u.role === "agent" && u.status === "pending").length === 0 ? (
                    <p className="text-xs text-amber-700 font-semibold italic">No pending agent verification requests in the registry.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-amber-50 text-amber-900 font-bold uppercase border-b border-amber-200">
                            <th className="p-3">Advisor Name / Email</th>
                            <th className="p-3">Allocated Country Scope</th>
                            <th className="p-3">Signed up At</th>
                            <th className="p-3 text-right">Instant Validation Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {users.filter(u => u.role === "agent" && u.status === "pending").map((u) => (
                            <tr key={u.id} className="border-b border-amber-100/50 hover:bg-amber-100/20">
                              <td className="p-3 flex items-center gap-2">
                                <img
                                  src={u.avatarUrl || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"}
                                  alt={u.name}
                                  className="w-8 h-8 rounded-full object-cover border border-amber-100"
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <div className="font-extrabold text-amber-950">{u.name}</div>
                                  <div className="text-[10px] text-amber-700">{u.email}</div>
                                </div>
                              </td>
                              <td className="p-3">
                                <div className="flex flex-wrap gap-1">
                                  {(!u.countries || u.countries.length === 0) ? (
                                    <span className="text-[9px] font-black uppercase text-emerald-800 bg-emerald-100 border border-emerald-250 px-2 py-0.5 rounded">
                                      Universal Access
                                    </span>
                                  ) : (
                                    u.countries.map(cid => (
                                      <span key={cid} className="text-[9px] font-bold text-indigo-850 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                                        {countries.find(c => c.id === cid)?.name || cid.toUpperCase()}
                                      </span>
                                    ))
                                  )}
                                </div>
                              </td>
                              <td className="p-3 text-amber-800 font-semibold">
                                {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "Demo"}
                              </td>
                              <td className="p-3 text-right">
                                <button
                                  onClick={() => onApproveUser(u.id)}
                                  className="px-3 py-1 text-[10px] font-extrabold text-amber-900 bg-amber-100 border border-amber-300 rounded-lg hover:bg-amber-200 transition-colors"
                                >
                                  Approve Agent Credentials
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Section B.2: Approved active agents list */}
                <div>
                  <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider mb-3">
                    Approved Certified Agent Advisors Directory
                  </h4>
                  {users.filter(u => u.role === "agent" && u.status === "approved").length === 0 ? (
                    <p className="text-xs text-gray-500 italic">No approved active agent specialist profiles.</p>
                  ) : (
                    <div className="overflow-x-auto bg-white rounded-2xl border border-gray-150">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-gray-50 text-gray-500 font-extrabold uppercase border-b border-gray-150">
                            <th className="p-3">Advisor profile / contact</th>
                            <th className="p-3">Authorized Countries Map</th>
                            <th className="p-3">Access Approved</th>
                            <th className="p-3 text-right">Administrative Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {users.filter(u => u.role === "agent" && u.status === "approved").map((u) => (
                            <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50/50">
                              <td className="p-3 flex items-center gap-2">
                                <img
                                  src={u.avatarUrl || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"}
                                  alt={u.name}
                                  className="w-8 h-8 rounded-full object-cover border border-gray-100"
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <div className="font-extrabold text-gray-900">{u.name}</div>
                                  <div className="text-[10px] text-gray-500">{u.email}</div>
                                </div>
                              </td>
                              <td className="p-3">
                                <div className="flex flex-wrap gap-1">
                                  {(!u.countries || u.countries.length === 0) ? (
                                    <span className="text-[10px] font-black uppercase text-emerald-800 bg-emerald-100 border border-emerald-255 px-2.5 py-1 rounded-lg flex items-center gap-1">
                                      <Globe className="w-3.5 h-3.5 text-emerald-600" /> Universal Work Scope
                                    </span>
                                  ) : (
                                    u.countries.map(cid => (
                                      <span key={cid} className="text-[10px] font-black text-indigo-850 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded-lg flex items-center gap-1">
                                        <Globe className="w-3.5 h-3.5 text-indigo-500" /> {countries.find(c => c.id === cid)?.name || cid.toUpperCase()}
                                      </span>
                                    ))
                                  )}
                                </div>
                              </td>
                              <td className="p-3 text-gray-500 font-bold">
                                {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "Demo"}
                              </td>
                              <td className="p-3 text-right">
                                <div className="inline-flex gap-1.5 justify-end">
                                  <button
                                    onClick={() => handleOpenCredentialModal(u)}
                                    className="px-2.5 py-1 text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors"
                                  >
                                    Edit Credentials & Country
                                  </button>
                                  {u.id !== user.id && (
                                    <button
                                      onClick={() => onDeleteUser(u.id)}
                                      className="p-1 px-2 border border-red-200 text-red-650 hover:bg-red-50 rounded-lg text-[10px] font-bold"
                                      title="Remove User Account"
                                    >
                                      Delete
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* C. ADMINISTRATORS PANEL */}
            {userRoleFilter === "admin" && (
              <div>
                <h4 className="text-xs font-bold text-gray-950 uppercase tracking-wider mb-3">
                  System administrators Registry
                </h4>
                <div className="overflow-x-auto bg-white rounded-2xl border border-gray-150">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 text-gray-500 font-extrabold uppercase border-b border-gray-150">
                        <th className="p-3">Administrator Name / Email</th>
                        <th className="p-3">Role</th>
                        <th className="p-3">Account Status</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.filter(u => u.role === "admin").map((u) => (
                        <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50/50">
                          <td className="p-3 flex items-center gap-2">
                            <img
                              src={u.avatarUrl || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200"}
                              alt={u.name}
                              className="w-8 h-8 rounded-full object-cover border border-gray-100"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <div className="font-extrabold text-gray-900">{u.name}</div>
                              <div className="text-[10px] text-gray-500">{u.email}</div>
                            </div>
                          </td>
                          <td className="p-3">
                            <span className="text-[10px] font-extrabold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                              {u.role.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 text-emerald-755 font-bold">
                            Active Admin
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => handleOpenCredentialModal(u)}
                              className="px-2.5 py-1 text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors"
                            >
                              Edit Credentials
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Pipeline / Application Stages view */}
        {activeSubTab === "pipelines" && (
          <div className="space-y-6 text-left" id="admin-pipelines-panel">
            <h3 className="text-lg font-extrabold text-gray-950 flex items-center justify-between pb-3 border-b border-gray-50">
              <span>Enrollment Portfolios & Pipeline Action Control</span>
            </h3>

            {applications.length === 0 ? (
              <p className="text-sm text-gray-500">No student enrollment portfolios in progress.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-50 text-gray-550 font-bold border-b border-gray-100 uppercase">
                      <th className="p-3">Applicant Name & ID</th>
                      <th className="p-3">Target University</th>
                      <th className="p-3">Portfolios & Drive Backup</th>
                      <th className="p-3">Current Pipeline stage</th>
                      <th className="p-3">Assigned Agent ID</th>
                      <th className="p-3 text-right">Application Stage Audit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {applications.map((app) => {
                      const stud = users.find(u => u.email.toLowerCase() === app.studentEmail.toLowerCase());
                      const displayId = stud?.studentId || app.studentId || "STU-PENDING";

                      return (
                        <tr key={app.id} className="border-b border-gray-150 hover:bg-gray-50/50">
                          <td className="p-3">
                            <div className="font-extrabold text-gray-900">{app.studentName}</div>
                            <div className="text-[10px] text-indigo-700 font-mono font-black mt-0.5 tracking-wider bg-indigo-50 border border-indigo-100 rounded-md px-1.5 py-0.5 inline-block">
                              {displayId}
                            </div>
                            <div className="text-[10px] text-gray-400 font-semibold mt-0.5">{app.studentEmail}</div>
                          </td>
                          <td className="p-3">
                            <p className="font-extrabold text-gray-800">{app.universityName}</p>
                            <span className="text-[10px] text-gray-400">{app.countryName}</span>
                            <div className="mt-1">
                              <span className="font-bold text-indigo-755 text-[10px] bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded block w-max">{app.program}</span>
                              <span className="text-[9px] text-gray-400 block mt-0.5 font-semibold">PP: {app.passportNumber}</span>
                            </div>
                          </td>
                          <td className="p-3">
                            {(!app.documents || app.documents.length === 0) ? (
                              <span className="text-[9px] text-gray-400 italic font-semibold">No portfolio files submitted yet.</span>
                            ) : (
                              <div className="space-y-2 max-w-xs">
                                {app.documents.map((doc, dIdx) => {
                                  const key = `${app.id}-${dIdx}`;
                                  const status = verifiedDocs[key] || 'idle';

                                  return (
                                    <div key={dIdx} className="p-2 bg-slate-50 border border-gray-150 rounded-xl space-y-1">
                                      <div className="flex items-center justify-between gap-2">
                                        <a
                                          href={doc.url}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          className="text-[10px] font-bold text-gray-700 hover:text-indigo-600 truncate underline"
                                          title={doc.name}
                                        >
                                          {doc.name} ({doc.size})
                                        </a>
                                      </div>

                                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                                        <span className="inline-flex items-center gap-0.5 text-[9px] font-black uppercase text-emerald-850 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                                          Drive Backup Linked
                                        </span>

                                        {status === 'idle' && (
                                          <button
                                            onClick={() => {
                                              setVerifiedDocs(prev => ({ ...prev, [key]: 'checking' }));
                                              setTimeout(() => {
                                                setVerifiedDocs(prev => ({ ...prev, [key]: 'active' }));
                                              }, 700);
                                            }}
                                            className="text-[9px] font-extrabold text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded px-1.5 py-0.5 cursor-pointer transition-colors"
                                          >
                                            Verify Link
                                          </button>
                                        )}

                                        {status === 'checking' && (
                                          <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">
                                            <RefreshCw className="w-2.5 h-2.5 animate-spin" /> Querying REST...
                                          </span>
                                        )}

                                        {status === 'active' && (
                                          <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase text-emerald-800 bg-emerald-100 border border-emerald-250 px-1.5 py-0.5 rounded-lg">
                                            <CheckCheck className="w-3 h-3 text-emerald-600" /> Operational (HTTP 200)
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </td>
                          <td className="p-3">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              app.status === 'Accepted by University' || app.status === 'Visa Application'
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-250 animate-bounce'
                                : app.status === 'Rejected'
                                ? 'bg-red-100 text-red-800 border border-red-250'
                                : app.status === 'First Phase' || app.status === 'First Phase Passed' || app.status === 'Pre-admission' || app.status === 'Getting Pre-admission'
                                ? 'bg-purple-100 text-purple-800 border border-purple-250'
                                : 'bg-indigo-100 text-indigo-800 border border-indigo-250'
                            }`}>
                              {app.status}
                            </span>
                          </td>
                          <td className="p-3 font-mono text-[10px] font-semibold text-gray-500">
                            {app.agentId ? (
                              <span className="font-extrabold text-slate-800">{users.find(u => u.id === app.agentId)?.name || app.agentId}</span>
                            ) : (
                              <span className="italic text-gray-400">Unassigned</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => {
                                  setSelectedAppId(app.id);
                                  const presets = ["Request to Agency", "Approved by Agency", "Application Submitted", "Initial Review", "First Phase", "First Phase Passed", "Pre-admission", "Getting Pre-admission", "Accepted by University", "Visa Application", "Rejected"];
                                  if (presets.includes(app.status)) {
                                    setNewPipelineStatus(app.status);
                                    setCustomAdminPipelineStatusText("");
                                    setShowAdminCustomInput(false);
                                    setAdminPortalScreenshot(app.portalScreenshot || "");
                                  } else {
                                    setNewPipelineStatus("Custom");
                                    setCustomAdminPipelineStatusText(app.status);
                                    setShowAdminCustomInput(true);
                                    setAdminPortalScreenshot(app.portalScreenshot || "");
                                  }
                                }}
                                className="px-2.5 py-1 text-[10px] font-extrabold text-indigo-900 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 rounded-lg whitespace-nowrap cursor-pointer transition-colors"
                              >
                                Set Stage Status
                              </button>

                              {onDeleteApplication && (
                                <button
                                  onClick={() => {
                                    onDeleteApplication(app.id);
                                  }}
                                  title="Delete Student Application"
                                  className="p-1 px-1.5 text-red-600 bg-red-50 border border-red-250 hover:bg-red-100 hover:text-red-700 rounded-lg cursor-pointer transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5 inline" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Quick status change subpanel */}
            {selectedAppId && (
              <div className="bg-indigo-50/50 p-5 rounded-2xl border border-indigo-200 mt-4 max-w-lg mx-auto">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wide text-indigo-950">Quick Pipeline Transition</h4>
                  <button onClick={() => setSelectedAppId(null)} className="p-1 hover:bg-indigo-100 rounded-full">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-655 uppercase tracking-wide mb-1">Status Action Level</label>
                    <select
                      value={newPipelineStatus}
                      onChange={(e) => {
                        const val = e.target.value;
                        setNewPipelineStatus(val);
                        setShowAdminCustomInput(val === "Custom");
                      }}
                      className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white font-bold text-gray-900"
                    >
                      <option value="Request to Agency">Request to Agency</option>
                      <option value="Approved by Agency">Approved by Agency</option>
                      <option value="Application Submitted">Application Submitted</option>
                      <option value="Initial Review">Initial Review</option>
                      <option value="First Phase">First Phase</option>
                      <option value="First Phase Passed">First Phase Passed</option>
                      <option value="Pre-admission">Pre-admission</option>
                      <option value="Getting Pre-admission">Getting Pre-admission</option>
                      <option value="Accepted by University">Accepted by University</option>
                      <option value="Visa Application">Visa Application</option>
                      <option value="Rejected">Rejected</option>
                      <option value="Custom">Custom Status...</option>
                    </select>
                  </div>

                  {showAdminCustomInput && (
                    <div>
                      <label className="block text-[10px] font-bold text-gray-655 uppercase tracking-wide mb-1">Enter Custom Status *</label>
                      <input
                        required
                        type="text"
                        value={customAdminPipelineStatusText}
                        onChange={(e) => setCustomAdminPipelineStatusText(e.target.value)}
                        placeholder="e.g. Under High Board Review..."
                        className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white font-extrabold text-gray-955"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] font-bold text-gray-655 uppercase tracking-wide mb-1">Director's Review Note *</label>
                    <textarea
                      value={pipelineNote}
                      onChange={(e) => setPipelineNote(e.target.value)}
                      placeholder="Add guidance or verify transcript results. Student tracks this real-time."
                      rows={2}
                      className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-655 uppercase tracking-wide mb-1">Upload Portal Screenshot (Optional)</label>
                    <div className="space-y-2">
                      <label className="flex flex-col items-center justify-center border border-dashed border-gray-200 hover:border-indigo-400 rounded-xl p-2.5 cursor-pointer bg-white transition-colors">
                        <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-bold uppercase">
                          <ImageIcon className="w-4 h-4 text-indigo-500" />
                          {adminPortalScreenshot ? "Change Attached Image" : "Select Screenshot file"}
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === "string") {
                                  setAdminPortalScreenshot(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                      {adminPortalScreenshot && (
                        <div className="relative group rounded-lg overflow-hidden border border-gray-150 bg-gray-50 max-h-24 flex items-center justify-center">
                          <img src={adminPortalScreenshot} alt="Pending admin upload preview" className="max-h-22 w-auto object-contain" referrerPolicy="no-referrer" />
                          <button
                            type="button"
                            onClick={() => setAdminPortalScreenshot("")}
                            className="absolute top-1 right-1 p-0.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors cursor-pointer"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-1 border-t border-indigo-150/50">
                    <button
                      onClick={() => {
                        setSelectedAppId(null);
                        setAdminPortalScreenshot("");
                      }}
                      className="px-3 py-1.5 text-xs text-gray-655 font-semibold bg-white border border-gray-200 rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handlePipelineStatusUpdate(selectedAppId)}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm"
                    >
                      Confirm Move
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Branding preferences view */}
        {activeSubTab === "branding" && (
          <form onSubmit={handleSaveBranding} className="space-y-4 text-left max-w-xl mx-auto" id="admin-branding-form">
            <h3 className="text-lg font-extrabold text-gray-950 pb-2 border-b border-gray-50 flex items-center gap-1">
              <Settings className="w-5 h-5 text-indigo-600" /> Agency Custom Branding & Logotype
            </h3>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Global Brand Registry Name</label>
              <input
                type="text"
                required
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 font-medium"
              />
              <span className="text-[10px] text-gray-400 mt-0.5 block">Changes reflect instantly at head logo panels and headers.</span>
            </div>

            {/* Custom Logo Image Upload & Preview */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-150 space-y-3">
              <label className="block text-xs font-semibold text-gray-700 uppercase">Agency Brand Logo Image</label>
              <div className="flex flex-col sm:flex-row items-center gap-4">
                {brandLogoUrl ? (
                  <div className="relative group w-20 h-20 bg-white border border-gray-150 rounded-xl overflow-hidden flex items-center justify-center p-1">
                    <img src={brandLogoUrl} alt="Agency Logo Preview" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                    <button
                      type="button"
                      onClick={() => setBrandLogoUrl("")}
                      className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-[10px] font-bold transition-opacity cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="w-20 h-20 bg-white border border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center text-gray-400">
                    <ImageIcon className="w-6 h-6 mb-1 text-gray-300" />
                    <span className="text-[9px] font-extrabold uppercase">No Logo</span>
                  </div>
                )}
                <div className="flex-1 space-y-1">
                  <label className="inline-flex items-center px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-750 text-xs font-bold rounded-lg cursor-pointer transition-colors">
                    Upload Custom Logo Image
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === "string") {
                              setBrandLogoUrl(reader.result);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  <span className="text-[10px] text-gray-400 block">This logo will be displayed on the header, footer, and login panels.</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Corner Initials Logo Text</label>
                <input
                  type="text"
                  required
                  maxLength={4}
                  value={brandLogo}
                  onChange={(e) => setBrandLogo(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Admissions Inquiries Email 1</label>
                <input
                  type="email"
                  required
                  value={brandEmail}
                  onChange={(e) => setBrandEmail(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Alternate Support Email 2</label>
                <input
                  type="email"
                  required
                  value={brandEmail2}
                  onChange={(e) => setBrandEmail2(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600"
                />
              </div>
            </div>

            <div className="border-t border-gray-100 pt-4 mt-2">
              <span className="text-[10px] font-black tracking-wider uppercase text-indigo-600 block mb-3">Homepage Welcome Letter & Stats Block</span>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Headline Promotion Message</label>
                  <input
                    type="text"
                    required
                    value={welcomeTitle}
                    onChange={(e) => setWelcomeTitle(e.target.value)}
                    className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 font-bold"
                    placeholder="e.g. Bridging Global Academic Excellence Since 2011"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Detailed Agency letter from Director / Team</label>
                  <textarea
                    required
                    rows={4}
                    value={welcomeLetter}
                    onChange={(e) => setWelcomeLetter(e.target.value)}
                    className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 leading-relaxed font-normal"
                    placeholder="Provide a letter introducing the agency, credentials, student cohorts assisted, and direct contact details before destination search begins."
                  />
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-750 uppercase mb-1">Assisted Students</label>
                    <input
                      type="text"
                      required
                      value={statsStudents}
                      onChange={(e) => setStatsStudents(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 bg-white font-bold text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-750 uppercase mb-1">Partner Colleges</label>
                    <input
                      type="text"
                      required
                      value={statsUniversities}
                      onChange={(e) => setStatsUniversities(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 bg-white font-bold text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-750 uppercase mb-1">Secured Scholarships</label>
                    <input
                      type="text"
                      required
                      value={statsScholarships}
                      onChange={(e) => setStatsScholarships(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 bg-white font-bold text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-750 uppercase mb-1">Visa Success %</label>
                    <input
                      type="text"
                      required
                      value={statsVisaRate}
                      onChange={(e) => setStatsVisaRate(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 bg-white font-bold text-gray-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                disabled={isSavingBranding}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold shadow-md inline-flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" /> {isSavingBranding ? "Saving configuration..." : "Save Branding Defaults"}
              </button>
            </div>
          </form>
        )}

        {/* Storage preferences view */}
        {activeSubTab === "storage" && (
          <form onSubmit={handleSaveStorage} className="space-y-4 text-left max-w-xl mx-auto" id="admin-storage-form">
            <h3 className="text-lg font-extrabold text-gray-950 pb-2 border-b border-gray-50 flex items-center gap-1">
              <Compass className="w-5 h-5 text-indigo-600" /> Secure Cloud Storage destination
            </h3>

            <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-amber-900 leading-relaxed text-xs">
              <AlertCircle className="w-4.5 h-4.5 text-amber-600 inline mr-1 align-middle" />
              <span>Configure your secure document storage coordinates. Files successfully mapped under this folder are isolated under security rules.</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Primary Provider Service</label>
              <select
                value={storeProvider}
                onChange={(e: any) => setStoreProvider(e.target.value)}
                className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white font-bold"
              >
                <option value="Google Drive">Google Drive Shared Folder</option>
                <option value="Firebase Storage">Firebase Cloud Storage (Standard Bucket)</option>
                <option value="Local Folders">Local Server Isolated Folders</option>
                <option value="Custom">Custom Content URL Mapping API</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Storage Destination Folder / Access link</label>
              <input
                type="text"
                required
                value={storeLink}
                onChange={(e) => setStoreLink(e.target.value)}
                className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 font-mono text-[11px]"
              />
              <span className="text-[10px] text-gray-400 mt-1 block">Students will see their portfolios backed up directly in this folder target link.</span>
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                disabled={isSavingStorage}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold shadow-md inline-flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" /> {isSavingStorage ? "Updating destination link..." : "Update Storage Link"}
              </button>
            </div>
          </form>
        )}

        {/* Academics, Directory & Scholarship Database Controls Section */}
        {activeSubTab === "academics" && (
          <div className="space-y-6 text-left" id="admin-academics-tab">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gray-100 pb-4 gap-4">
              <div>
                <h3 className="text-lg font-extrabold text-gray-950 flex items-center gap-1.5">
                  <Award className="w-5 h-5 text-emerald-555" /> Academic & Scholarship Catalog Registrar (Full Access)
                </h3>
                <p className="text-xs text-gray-500 mt-1">Configure global destinations, partner institutes, and fully featured academic scholarship programs.</p>
              </div>

              {/* Sub-pills for Academics Panel */}
              <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200">
                <button
                  onClick={() => setActiveAcademicsSubTab("countries")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeAcademicsSubTab === "countries"
                      ? "bg-white text-indigo-750 shadow-xs"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                  id="academics-countries-pill"
                >
                  1. Countries ({countries.length})
                </button>
                <button
                  onClick={() => setActiveAcademicsSubTab("universities")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeAcademicsSubTab === "universities"
                      ? "bg-white text-indigo-750 shadow-xs"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                  id="academics-unis-pill"
                >
                  2. Universities ({universities.length})
                </button>
                <button
                  onClick={() => setActiveAcademicsSubTab("scholarships")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeAcademicsSubTab === "scholarships"
                      ? "bg-white text-indigo-750 shadow-xs"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                  id="academics-schs-pill"
                >
                  3. Scholarships ({universities.filter(u => u.scholarship?.title).length})
                </button>
              </div>
            </div>

            {/* --- Countries Management Section --- */}
            {activeAcademicsSubTab === "countries" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-450">Destination Country Registry</span>
                  {!isAddingCountry && (
                    <button
                      onClick={handleOpenAddCountry}
                      className="inline-flex items-center gap-1 text-xs bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-xl transition-all"
                      id="add-country-trigger"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Country
                    </button>
                  )}
                </div>

                {isAddingCountry && (
                  <form onSubmit={handleCountrySubmit} className="bg-gray-50 border border-gray-200 p-5 rounded-2xl max-w-xl space-y-3" id="admin-country-form">
                    <h4 className="text-xs font-extrabold uppercase text-indigo-950 tracking-wider">
                      {editingCountryId ? "✏️ Edit Country Details" : "🆕 Register New Country"}
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Country Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. United Kingdom"
                          value={countryName}
                          onChange={(e) => setCountryName(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Image / Photo Option</label>
                        <div className="space-y-1">
                          <input
                            type="text"
                            placeholder="Image URL link..."
                            value={countryImageUrl}
                            onChange={(e) => setCountryImageUrl(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                          />
                          <label className="flex items-center gap-1.5 cursor-pointer text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100/80 px-2 py-1 rounded-lg justify-center transition-colors font-semibold">
                            <ImageIcon className="w-3.5 h-3.5" />
                            <span>Or upload local image file</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    if (typeof reader.result === "string") {
                                      setCountryImageUrl(reader.result);
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Description *</label>
                      <textarea
                        required
                        rows={2}
                        placeholder="Brief summary of visas and study opportunities."
                        value={countryDescription}
                        onChange={(e) => setCountryDescription(e.target.value)}
                        className="w-full text-xs px-3 mt-1 py-1.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingCountry(false);
                          setEditingCountryId(null);
                        }}
                        className="px-3 py-1.5 text-xs text-gray-650 bg-white border border-gray-200 rounded-lg hover:bg-gray-100"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-655 hover:bg-indigo-700 rounded-lg"
                      >
                        {editingCountryId ? "Save Country Changes" : "Create Country"}
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {countries.map((c) => (
                    <div key={c.id} className="bg-white border border-gray-150 rounded-2xl p-4 flex gap-3 relative hover:border-gray-300">
                      <img
                        src={c.imageUrl}
                        alt={c.name}
                        className="w-16 h-16 rounded-xl object-cover border border-gray-150 self-start"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 text-left">
                        <h4 className="font-extrabold text-gray-900 text-sm flex items-center justify-between">
                          <span>{c.name}</span>
                          <span className="text-[10px] font-mono text-gray-400 bg-gray-50 px-1.5 py-0.5 rounded">ID: {c.id}</span>
                        </h4>
                        <p className="text-xs text-gray-505 mt-1 line-clamp-2 leading-normal">{c.description}</p>
                        <div className="mt-3 flex gap-2 justify-end">
                          <button
                            onClick={() => handleOpenEditCountry(c)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 rounded-lg hover:bg-indigo-100"
                          >
                            <Edit3 className="w-3 h-3" /> Edit Country
                          </button>
                          <button
                            onClick={() => handleDeleteCountryClick(c.id, c.name)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold text-red-750 bg-red-50 border border-red-150 rounded-lg hover:bg-red-100"
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* --- Universities Management Section --- */}
            {activeAcademicsSubTab === "universities" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-450">Active Partner Universities</span>
                  {!isAddingUniversity && (
                    <button
                      onClick={handleOpenAddUni}
                      className="inline-flex items-center gap-1 text-xs bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-xl transition-all"
                      id="add-uni-trigger"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add University
                    </button>
                  )}
                </div>

                {isAddingUniversity && (
                  <form onSubmit={handleUniversitySubmit} className="bg-gray-50 border border-gray-200 p-5 rounded-2xl max-w-xl space-y-4" id="admin-uni-form">
                    <h4 className="text-xs font-extrabold uppercase text-indigo-955 tracking-wider">
                      {editingUniversityId ? "✏️ Edit Partner University" : "🆕 Add Partner University"}
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">University Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Oxford University"
                          value={uniName}
                          onChange={(e) => setUniName(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Destination Country *</label>
                        <select
                          required
                          value={uniCountryId}
                          onChange={(e) => setUniCountryId(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white font-bold text-gray-900"
                        >
                          <option value="">Select country...</option>
                          {countries.map((c) => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Image / Photo Option</label>
                        <div className="space-y-1">
                          <input
                            type="text"
                            placeholder="https://images.unsplash.com/..."
                            value={uniImageUrl}
                            onChange={(e) => setUniImageUrl(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-xl border border-gray-200 bg-white"
                          />
                          <label className="flex items-center gap-1.5 cursor-pointer text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100/80 px-2 py-1 rounded-lg justify-center transition-colors font-semibold">
                            <ImageIcon className="w-3.5 h-3.5" />
                            <span>Or upload local image file</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    if (typeof reader.result === "string") {
                                      setUniImageUrl(reader.result);
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Study Programs (comma-separated)</label>
                        <input
                          type="text"
                          placeholder="Bachelor, Master, PhD"
                          value={uniPrograms}
                          onChange={(e) => setUniPrograms(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Major Disciplines & Subjects (comma-separated)</label>
                      <input
                        type="text"
                        placeholder="Computer Science, Business Administration, Data Technology"
                        value={uniSubjects}
                        onChange={(e) => setUniSubjects(e.target.value)}
                        className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                      />
                    </div>

                    {/* Integrated Scholarship details section */}
                    <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 space-y-3">
                      <span className="text-[10px] uppercase font-black text-indigo-950 tracking-wider block">Add Scholarship option directly to University</span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Scholarship Title</label>
                          <input
                            type="text"
                            placeholder="e.g. Excellence Vice-Chancellor Grant"
                            value={uniSchTitle}
                            onChange={(e) => setUniSchTitle(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Funding Award Sum (Amount)</label>
                          <input
                            type="text"
                            placeholder="e.g. £14,500 Tuition Waiver"
                            value={uniSchAmount}
                            onChange={(e) => setUniSchAmount(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 py-1">
                        <input
                          type="checkbox"
                          id="uniSchFully"
                          checked={uniSchFully}
                          onChange={(e) => setUniSchFully(e.target.checked)}
                          className="rounded border-gray-300 text-indigo-650"
                        />
                        <label htmlFor="uniSchFully" className="text-xs font-bold text-gray-700">This is a 100% Fully Funded Scholarship program</label>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Brief Description of Fellowship coverage</label>
                        <input
                          type="text"
                          placeholder="e.g. Covers full tuition cost and living stipends for academic period."
                          value={uniSchDesc}
                          onChange={(e) => setUniSchDesc(e.target.value)}
                          className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                        />
                      </div>
                    </div>

                    {/* University Application Deadlines & Admin Comments Segment */}
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100/50 space-y-3">
                      <span className="text-[10px] uppercase font-black text-amber-900 tracking-wider block flex items-center gap-1">
                        <Calendar className="w-4 h-4 text-amber-600" /> Intake Application Deadlines
                      </span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Summer Intake Deadline</label>
                          <input
                            type="date"
                            value={uniSummerDeadline}
                            onChange={(e) => setUniSummerDeadline(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Fall Intake Deadline</label>
                          <input
                            type="date"
                            value={uniFallDeadline}
                            onChange={(e) => setUniFallDeadline(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Special Admin Note / Comment for this University</label>
                        <textarea
                          rows={2}
                          placeholder="e.g. Early registrations gets priority screening or embassy recommendation letters."
                          value={uniAdminComment}
                          onChange={(e) => setUniAdminComment(e.target.value)}
                          className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingUniversity(false);
                          setEditingUniversityId(null);
                        }}
                        className="px-3 py-1.5 text-xs text-gray-650 bg-white border border-gray-200 rounded-lg hover:bg-gray-100"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
                      >
                        {editingUniversityId ? "Update Partner Uni" : "Register Partner Uni"}
                      </button>
                    </div>
                  </form>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 uppercase text-[10px] font-bold text-gray-450 border-b border-gray-100">
                        <th className="p-3">University / Country Location</th>
                        <th className="p-3">Programs Offered</th>
                        <th className="p-3">Primary Subjects</th>
                        <th className="p-3">Associated Scholarship</th>
                        <th className="p-3 text-right">Directory Options</th>
                      </tr>
                    </thead>
                    <tbody>
                      {universities.map((u) => {
                        const targetCountry = countries.find((c) => c.id === u.countryId)?.name || u.countryId || "Global";
                        return (
                          <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                            <td className="p-3">
                              <div className="flex items-center gap-2">
                                <img
                                  src={u.imageUrl || "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800"}
                                  alt={u.name}
                                  className="w-10 h-10 rounded-lg object-cover border border-gray-150"
                                  referrerPolicy="no-referrer"
                                  onError={(e) => {
                                    e.currentTarget.src = "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800";
                                  }}
                                />
                                <div>
                                  <div className="font-extrabold text-gray-900">{u.name}</div>
                                  <div className="text-[10px] text-gray-450 font-bold">{targetCountry} Destination</div>
                                </div>
                              </div>
                            </td>
                            <td className="p-3">
                              <div className="flex flex-wrap gap-1">
                                {u.programs.map((p, pIdx) => (
                                  <span key={pIdx} className="bg-indigo-50 border border-indigo-100 rounded text-[9px] px-1 font-bold text-indigo-700">{p}</span>
                                ))}
                              </div>
                            </td>
                            <td className="p-3 max-w-xs truncate text-gray-650 font-semibold">{u.subjects.join(", ")}</td>
                            <td className="p-3">
                              {u.scholarship?.title ? (
                                <div>
                                  <span className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                    u.scholarship.isFullyFunded ? "bg-amber-100 text-amber-800 border border-amber-200" : "bg-indigo-50 text-indigo-700 border border-indigo-150"
                                  }`}>
                                    🏆 {u.scholarship.title}
                                  </span>
                                  <div className="text-[9px] text-gray-400 mt-0.5 font-bold">Sum: {u.scholarship.amount || "Partial Waiver"}</div>
                                </div>
                              ) : (
                                <span className="text-[10px] text-gray-400">None mapped</span>
                              )}
                            </td>
                            <td className="p-3 text-right">
                              <div className="inline-flex gap-1.5 justify-end">
                                <button
                                  onClick={() => handleOpenEditUni(u)}
                                  className="p-1.5 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-150 rounded-lg"
                                  title="Edit University File"
                                >
                                  <Edit3 className="w-3.5 h-3.5" /> Edit Uni
                                </button>
                                <button
                                  onClick={() => handleDeleteUniClick(u.id, u.name)}
                                  className="p-1.5 text-red-705 bg-red-50 hover:bg-red-100 border border-red-150 rounded-lg"
                                  title="Remove University Record"
                                >
                                  <Trash2 className="w-3.5 h-3.5" /> Delete
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* --- Dedicated Scholarships Management Section --- */}
            {activeAcademicsSubTab === "scholarships" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-455">Scholarship programs & Foundations</span>
                  {!isAddingSch && (
                    <button
                      onClick={handleOpenAddSch}
                      className="inline-flex items-center gap-1 text-xs bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-xl transition-all"
                      id="add-scholarship-trigger"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Scholarship Program
                    </button>
                  )}
                </div>

                {isAddingSch && (
                  <form onSubmit={handleScholarshipSubmit} className="bg-gray-50 border border-gray-200 p-5 rounded-2xl max-w-xl space-y-4" id="admin-scholarship-only-form">
                    <h4 className="text-xs font-extrabold uppercase text-indigo-950 tracking-wider">
                      {editingSchUniId ? "✏️ Edit Scholarship Program" : "🆕 Register Scholarship Option"}
                    </h4>

                    {/* Choose university */}
                    {!editingSchUniId ? (
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Target University *</label>
                        <select
                          required
                          value={selectedSchUniId}
                          onChange={(e) => setSelectedSchUniId(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white font-bold text-gray-900"
                        >
                          <option value="">Select target university...</option>
                          {universities.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.name} {u.scholarship?.title ? " (Has active scholarship: " + u.scholarship.title + ")" : ""}
                            </option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <div>
                        <span className="text-[10px] uppercase font-bold text-gray-405 block mb-0.5">Editing Scholarship of University</span>
                        <p className="font-extrabold text-gray-800 text-sm">
                          {universities.find(u => u.id === editingSchUniId)?.name}
                        </p>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Scholarship Title *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Dean's Academic Fellowship"
                          value={schTitle}
                          onChange={(e) => setSchTitle(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Award Amount / Stipend *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. $12,500 per annum"
                          value={schAmount}
                          onChange={(e) => setSchAmount(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 py-1">
                      <input
                        type="checkbox"
                        id="schFully"
                        checked={schFully}
                        onChange={(e) => setSchFully(e.target.checked)}
                        className="rounded border-gray-300 text-indigo-650"
                      />
                      <label htmlFor="schFully" className="text-xs font-bold text-gray-700">Mark as 100% Fully Funded Award</label>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Detailed Description of Scholarship criteria</label>
                      <textarea
                        rows={3}
                        placeholder="Detail performance thresholds, subject categories, and renewal conditions."
                        value={schDescription}
                        onChange={(e) => setSchDescription(e.target.value)}
                        className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white"
                      />
                    </div>

                    {/* Scholarship Deadlines & Admin Comments Section */}
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100/50 space-y-3">
                      <span className="text-[10px] uppercase font-black text-amber-900 tracking-wider block flex items-center gap-1">
                        <Calendar className="w-4 h-4 text-amber-600" /> Scholarship Intake Deadlines
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Summer Intake Deadline</label>
                          <input
                            type="date"
                            value={schSummerDeadline}
                            onChange={(e) => setSchSummerDeadline(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Fall Intake Deadline</label>
                          <input
                            type="date"
                            value={schFallDeadline}
                            onChange={(e) => setSchFallDeadline(e.target.value)}
                            className="w-full text-xs px-3 py-1.5 rounded-lg border border-gray-150 bg-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Special Admin Note / Comment for this Scholarship</label>
                        <textarea
                          rows={2}
                          placeholder="e.g. Open to international students directly via embassy review channels."
                          value={schAdminComment}
                          onChange={(e) => setSchAdminComment(e.target.value)}
                          className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingSch(false);
                          setEditingSchUniId(null);
                        }}
                        className="px-3 py-1.5 text-xs text-gray-655 bg-white border border-gray-200 rounded-lg"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-650 hover:bg-indigo-700 rounded-lg"
                      >
                        {editingSchUniId ? "Save Scholarship details" : "Attach Scholarship program"}
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {universities
                    .filter((u) => u.scholarship && u.scholarship.title)
                    .map((u) => (
                      <div 
                        key={u.id} 
                        className={`bg-white border text-left p-5 rounded-2xl relative flex flex-col justify-between ${
                          u.scholarship?.isFullyFunded ? "border-amber-300 shadow-xs ring-1 ring-amber-100" : "border-gray-150"
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <span className="text-[10px] uppercase font-bold text-indigo-450 block">Partner College</span>
                              <h5 className="font-extrabold text-sm text-indigo-950 leading-tight">{u.name}</h5>
                            </div>
                            {u.scholarship?.isFullyFunded && (
                              <span className="bg-amber-100 text-amber-800 text-[9px] font-black uppercase px-2 py-0.5 rounded border border-amber-200">
                                Fully Funded
                              </span>
                            )}
                          </div>

                          <div className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-150 rounded-lg px-2.5 py-1 text-xs font-bold my-1">
                            🏆 {u.scholarship?.title}
                          </div>

                          <p className="text-xs text-gray-500 mt-2 italic leading-relaxed">
                            "{u.scholarship?.description || "Covers general university expenses for deserving enrolled students based on grades."}"
                          </p>

                          <div className="mt-4 pt-3 border-t border-gray-100 grid grid-cols-2 gap-2 text-[11px]">
                            <div>
                              <span className="text-[9px] uppercase font-bold text-gray-400 block">Funds/Grant</span>
                              <span className="font-extrabold text-gray-800">{u.scholarship?.amount || "Partial Waiver"}</span>
                            </div>
                            <div>
                              <span className="text-[9px] uppercase font-bold text-gray-400 block">Category</span>
                              <span className="font-extrabold text-gray-800">{u.subjects[0] || "All Majors"}</span>
                            </div>
                          </div>

                          {/* Deadlines list item rendering inside Admin Panel */}
                          {(u.scholarship?.summerDeadline || u.scholarship?.fallDeadline || u.scholarship?.adminComment) && (
                            <div className="mt-3 p-2 bg-slate-50 border border-slate-100 rounded-xl space-y-1 text-[10px]">
                              {u.scholarship.summerDeadline && (
                                <div className="flex justify-between items-center bg-white p-1 rounded border border-gray-150">
                                  <span>Summer Intake</span>
                                  <span className="font-extrabold text-indigo-900">{formatDate(u.scholarship.summerDeadline)}</span>
                                </div>
                              )}
                              {u.scholarship.fallDeadline && (
                                <div className="flex justify-between items-center bg-white p-1 rounded border border-gray-150">
                                  <span>Fall Intake</span>
                                  <span className="font-extrabold text-indigo-900">{formatDate(u.scholarship.fallDeadline)}</span>
                                </div>
                              )}
                              {u.scholarship.adminComment && (
                                <div className="text-[9px] text-amber-800 italic leading-snug bg-amber-50/50 p-1.5 rounded border border-amber-100 flex gap-0.5 items-start mt-1">
                                  <MessageSquare className="w-3 h-3 text-amber-600 shrink-0 mt-0.5" />
                                  <span>{u.scholarship.adminComment}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="mt-4 pt-3 border-t border-gray-100 flex justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEditSch(u)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 rounded-lg hover:bg-indigo-100"
                          >
                            <Edit3 className="w-3 h-3" /> Edit Scholarship
                          </button>
                          <button
                            onClick={() => handleRemoveSchClick(u)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-[10px] font-bold text-red-700 bg-red-50 border border-red-150 rounded-lg hover:bg-red-100"
                          >
                            <Trash2 className="w-3 h-3" /> Remove
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* System & Portal Access Control Settings */}
        {activeSubTab === "system-settings" && (
          <div className="space-y-6 text-left animate-fade-in" id="admin-system-settings-panel">
            <div>
              <h3 className="text-lg font-extrabold text-gray-950 flex items-center gap-1.5 pb-2 border-b border-gray-50">
                <Shield className="w-5 h-5 text-rose-500" /> Platform Access Gates & Integrity Controllers
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                Deactivate or restrict registrations and logins for students and partner advisors independently.
              </p>
            </div>

            <div className="bg-rose-50 border border-rose-150 p-4 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-rose-950 block">Operational High-Priority Notice</span>
                <span className="text-xs text-rose-700 font-medium">
                  Deactivating login overrides will immediately invalidate current sessions. Deactivating registrations will block all standard candidate registration requests.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="system-gates-grid">
              
              {/* STUDENT ACCESS GATE */}
              <div className="bg-slate-50 border border-slate-150 rounded-2xl p-6 space-y-4">
                <h4 className="text-xs font-black uppercase text-indigo-950 tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-2">
                  🎓 Student Access Configuration
                </h4>
                
                {/* Student Login Control */}
                <div className="flex items-center justify-between p-3.5 bg-white border border-gray-150 rounded-xl">
                  <div className="max-w-[70%]">
                    <span className="text-xs font-extrabold text-gray-900 block">Student Login Services</span>
                    <span className="text-[10px] text-gray-400 font-medium block leading-normal">Allow existing verified students to sign in to their portfolios.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSystemSettings({ disableStudentLogin: !systemSettings.disableStudentLogin })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      !systemSettings.disableStudentLogin ? "bg-emerald-500" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        !systemSettings.disableStudentLogin ? "translate-x-5 animate-pulse" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* Student Registration Control */}
                <div className="flex items-center justify-between p-3.5 bg-white border border-gray-150 rounded-xl">
                  <div className="max-w-[70%]">
                    <span className="text-xs font-extrabold text-gray-900 block">Student Registration Queue</span>
                    <span className="text-[10px] text-gray-400 font-medium block leading-normal">Allow new prospective students to sign up or join from front landing views.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSystemSettings({ disableStudentRegister: !systemSettings.disableStudentRegister })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      !systemSettings.disableStudentRegister ? "bg-emerald-500" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        !systemSettings.disableStudentRegister ? "translate-x-5 animate-pulse" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-950">Current Student Gate State:</span>
                  <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded ${
                    (!systemSettings.disableStudentLogin && !systemSettings.disableStudentRegister)
                      ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                      : "bg-amber-100 text-amber-800 border border-amber-200"
                  }`}>
                    {(!systemSettings.disableStudentLogin && !systemSettings.disableStudentRegister) ? "Fully Active" : "Partially Restricted"}
                  </span>
                </div>
              </div>

              {/* AGENT ACCESS GATE */}
              <div className="bg-slate-50 border border-slate-150 rounded-2xl p-6 space-y-4">
                <h4 className="text-xs font-black uppercase text-indigo-950 tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-2">
                  💼 Senior Agent Access Configuration
                </h4>
                
                {/* Agent Login Control */}
                <div className="flex items-center justify-between p-3.5 bg-white border border-gray-150 rounded-xl">
                  <div className="max-w-[70%]">
                    <span className="text-xs font-extrabold text-gray-900 block">Agent Login Services</span>
                    <span className="text-[10px] text-gray-400 font-medium block leading-normal">Allow registered Senior Admissions Advisors to sign in and review pipelines.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSystemSettings({ disableAgentLogin: !systemSettings.disableAgentLogin })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      !systemSettings.disableAgentLogin ? "bg-emerald-500" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        !systemSettings.disableAgentLogin ? "translate-x-5 animate-pulse" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* Agent Registration Control */}
                <div className="flex items-center justify-between p-3.5 bg-white border border-gray-150 rounded-xl">
                  <div className="max-w-[70%]">
                    <span className="text-xs font-extrabold text-gray-900 block">Agent Registration Queue</span>
                    <span className="text-[10px] text-gray-400 font-medium block leading-normal">Allow new counselor team members to sign up for agency review.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSystemSettings({ disableAgentRegister: !systemSettings.disableAgentRegister })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      !systemSettings.disableAgentRegister ? "bg-emerald-500" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        !systemSettings.disableAgentRegister ? "translate-x-5 animate-pulse" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-950">Current Agent Gate State:</span>
                  <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded ${
                    (!systemSettings.disableAgentLogin && !systemSettings.disableAgentRegister)
                      ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                      : "bg-amber-100 text-amber-800 border border-amber-200"
                  }`}>
                    {(!systemSettings.disableAgentLogin && !systemSettings.disableAgentRegister) ? "Fully Active" : "Partially Restricted"}
                  </span>
                </div>
              </div>

            </div>
          </div>
        )}
      </div>

      {/* Account Credentials View & Edit Modal */}
      {isCredentialModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4" id="credential-modal">
          <div className="bg-white rounded-3xl border border-gray-150 p-6 w-full max-w-md shadow-2xl relative text-left">
            <button
              onClick={() => setIsCredentialModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-700 rounded-full transition-colors cursor-pointer animate-fade-in"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-5 border-b border-gray-100 pb-3">
              <div className="p-2 bg-indigo-50 rounded-xl text-indigo-600">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-gray-900 tracking-tight">Credentials & Access Controller</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Audit & Update User Credentials</p>
              </div>
            </div>

            <form onSubmit={handleSaveCredentials} className="space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-[10px] uppercase font-black text-gray-500 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editingUserName}
                  onChange={(e) => setEditingUserName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-gray-900 font-semibold"
                />
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-[10px] uppercase font-black text-gray-500 mb-1">Email Address (Login Username)</label>
                <input
                  type="email"
                  required
                  value={editingUserEmail}
                  onChange={(e) => setEditingUserEmail(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-gray-900 font-semibold"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-[10px] uppercase font-black text-gray-500 mb-1">Account Password</label>
                <div className="relative">
                  <input
                    type={isPasswordVisible ? "text" : "password"}
                    required
                    value={editingUserPassword}
                    onChange={(e) => setEditingUserPassword(e.target.value)}
                    className="w-full text-xs px-3.5 py-2 pr-10 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-gray-900 font-mono font-bold"
                  />
                  <button
                    type="button"
                    onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 focus:outline-none cursor-pointer"
                  >
                    {isPasswordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Role & Status Row */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-black text-gray-500 mb-1">System Role</label>
                  <select
                    value={editingUserRole}
                    onChange={(e) => setEditingUserRole(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-gray-900 font-semibold"
                  >
                    <option value="student">student</option>
                    <option value="agent">agent</option>
                    <option value="admin">admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-black text-gray-500 mb-1">Validation Status</label>
                  <select
                    value={editingUserStatus}
                    onChange={(e) => setEditingUserStatus(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-gray-900 font-semibold"
                  >
                    <option value="pending">pending</option>
                    <option value="approved">approved</option>
                  </select>
                </div>
              </div>

              {/* Unique Student ID Override (Visible for 'student') */}
              {editingUserRole === "student" && (
                <div className="bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-150 animate-fade-in">
                  <label className="block text-[10px] uppercase font-black text-indigo-950 mb-1">Student ID (Durable Registry Key)</label>
                  <input
                    type="text"
                    required
                    value={editingUserStudentId}
                    onChange={(e) => setEditingUserStudentId(e.target.value)}
                    placeholder="e.g. STU-482104"
                    className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white text-indigo-800 font-mono font-black tracking-wider"
                  />
                  <p className="text-[9px] text-gray-400 font-semibold mt-1">Unique alphanumeric index. Override only if specific audit trails require manual indexing.</p>
                </div>
              )}

              {/* Authorized Countries scope (Visible for 'agent') */}
              {editingUserRole === "agent" && (
                <div className="bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-150 space-y-2 animate-fade-in">
                  <label className="block text-[10px] uppercase font-black text-indigo-950">Authorized Countries Map</label>
                  <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto bg-white border border-gray-200 p-2 rounded-xl">
                    {countries.length === 0 ? (
                      <p className="text-[10px] text-gray-400 italic col-span-2">No countries created in database.</p>
                    ) : (
                      countries.map((c) => {
                        const isChecked = editingUserCountries.includes(c.id);
                        return (
                          <label key={c.id} className="flex items-center gap-2 text-[11px] font-bold text-gray-700 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setEditingUserCountries([...editingUserCountries, c.id]);
                                } else {
                                  setEditingUserCountries(editingUserCountries.filter(cid => cid !== c.id));
                                }
                              }}
                              className="rounded border-gray-300 text-indigo-650 focus:ring-indigo-500 w-3.5 h-3.5 cursor-pointer"
                            />
                            <span>{c.name}</span>
                          </label>
                        );
                      })
                    )}
                  </div>
                  <p className="text-[9px] text-gray-400 font-semibold mt-1">Configure active global hubs authorized for this advisor. Empty means universal system access.</p>
                </div>
              )}

              <div className="pt-4 border-t border-gray-100 flex items-center justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setIsCredentialModalOpen(false)}
                  className="px-4 py-2 border border-gray-200 hover:bg-gray-50 rounded-xl text-gray-700 font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-650 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" /> Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Custom Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in" id="confirm-dialog-modal">
          <div className="bg-white rounded-3xl border border-gray-150 p-6 w-full max-w-sm shadow-2xl relative text-left text-xs text-gray-900 font-sans">
            <h4 className="text-sm font-extrabold text-gray-900 flex items-center gap-1.5 mb-2">
              ⚠️ Delete Confirmation
            </h4>
            <p className="text-xs text-gray-550 mb-6 leading-relaxed">
              Are you sure you want to delete <strong>{deleteConfirm.name}</strong>?
              {deleteConfirm.type === "country" && " This will remove it from the directory."}
              {deleteConfirm.type === "university" && " This will permanently remove this university's partner record."}
              {deleteConfirm.type === "scholarship" && " This will remove the scholarship program and decouple it from the university."}
            </p>
            <div className="flex items-center justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 border border-gray-200 hover:bg-gray-50 rounded-xl text-gray-700 font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-650 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
