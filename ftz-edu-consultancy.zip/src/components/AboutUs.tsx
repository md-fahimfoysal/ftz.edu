import React, { useState } from "react";
import { Staff, User, Branding } from "../types";
import { Plus, Trash2, Edit3, UserPlus, Image as ImageIcon, Sparkles, X, Check } from "lucide-react";

interface AboutUsProps {
  staff: Staff[];
  user: User | null;
  onAddStaff: (newStaff: Omit<Staff, "id">) => Promise<void>;
  onUpdateStaff: (id: string, updated: Partial<Staff>) => Promise<void>;
  onDeleteStaff: (id: string) => Promise<void>;
  branding?: Branding;
}

const PRESET_AVATARS = [
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300",
  "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=300",
  "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=300",
  "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=300",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300"
];

export default function AboutUs({ staff, user, onAddStaff, onUpdateStaff, onDeleteStaff, branding }: AboutUsProps) {
  const isAdmin = user?.role === "admin";
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [formName, setFormName] = useState("");
  const [formRole, setFormRole] = useState("");
  const [formBio, setFormBio] = useState("");
  const [formImage, setFormImage] = useState(PRESET_AVATARS[0]);

  // Handle uploading simulation
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpenAdd = () => {
    setFormName("");
    setFormRole("");
    setFormBio("");
    setFormImage(PRESET_AVATARS[Math.floor(Math.random() * PRESET_AVATARS.length)]);
    setIsAdding(true);
    setEditingId(null);
  };

  const handleOpenEdit = (member: Staff) => {
    setFormName(member.name);
    setFormRole(member.role);
    setFormBio(member.bio);
    setFormImage(member.imageUrl);
    setEditingId(member.id);
    setIsAdding(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formRole) return;

    if (editingId) {
      await onUpdateStaff(editingId, {
        name: formName,
        role: formRole,
        bio: formBio,
        imageUrl: formImage
      });
      setEditingId(null);
    } else {
      await onAddStaff({
        name: formName,
        role: formRole,
        bio: formBio,
        imageUrl: formImage
      });
      setIsAdding(false);
    }
  };

  return (
    <div className="py-8 px-4 max-w-7xl mx-auto" id="about-section">
      {/* Banner / Intro */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
          Meet Our Team
        </span>
        <h1 className="text-4xl font-extrabold text-gray-900 mt-3 tracking-tight">
          Pioneering Academic Consultancy Since 2011
        </h1>
        <p className="text-base text-gray-600 mt-4 leading-relaxed">
          At {branding?.name || "GlobalEdu Consultancy"}, our elite advisors offer seamless support in university selection, enrollment procedures, documentation auditing, scholarship opportunities, and full visa validation procedures.
        </p>

        {isAdmin && !isAdding && !editingId && (
          <button
            onClick={handleOpenAdd}
            className="mt-6 inline-flex items-center gap-2 bg-indigo-600 text-white font-semibold text-sm px-5 py-2.5 rounded-xl hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
            id="admin-add-staff-btn"
          >
            <UserPlus className="w-4 h-4" /> Add Team Member
          </button>
        )}
      </div>

      {/* Editor Panel wrapper */}
      {(isAdding || editingId) && (
        <div className="mb-12 max-w-2xl mx-auto bg-gray-50 border border-gray-200 p-6 rounded-2xl shadow-xs" id="staff-form-panel">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-900">
              {editingId ? "Edit Staff Credentials" : "Register New Consultancy Advisor"}
            </h3>
            <button
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
              }}
              className="p-1 text-gray-400 hover:text-gray-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Dr. Catherine Vance"
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-indigo-600 placeholder:text-gray-400 bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Designated Role *</label>
                <input
                  type="text"
                  required
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value)}
                  placeholder="e.g. Senior Admission Supervisor"
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-indigo-600 placeholder:text-gray-400 bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Brief Bio</label>
              <textarea
                value={formBio}
                onChange={(e) => setFormBio(e.target.value)}
                rows={3}
                placeholder="Describe qualifications, university placement history, or client portfolio..."
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-indigo-600 placeholder:text-gray-400 bg-white"
              />
            </div>

            {/* Profile Photo Upload and Presets */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Advisor Portrait Photo</label>
              
              <div className="flex flex-wrap items-center gap-4 bg-white p-3 rounded-xl border border-gray-100">
                <img
                  src={formImage}
                  alt="Preview"
                  className="w-16 h-16 rounded-xl object-cover border border-indigo-200 shadow-sm"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer inline-flex items-center gap-1 bg-gray-100 text-gray-800 text-xs px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors">
                      <ImageIcon className="w-3.5 h-3.5" /> File Upload
                      <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                    </label>
                    <span className="text-[10px] text-gray-400">or Choose Professional Portrait standard:</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {PRESET_AVATARS.map((preset, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setFormImage(preset)}
                        className={`w-8 h-8 rounded-full border-2 overflow-hidden transition-all ${
                          formImage === preset ? "border-indigo-600 scale-110 shadow-sm" : "border-transparent opacity-80 hover:opacity-100"
                        }`}
                      >
                        <img src={preset} alt="preset" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                }}
                className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-gray-250 rounded-xl hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 inline-flex items-center gap-1 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md transition-colors"
              >
                <Check className="w-4 h-4" /> {editingId ? "Save Changes" : "Register Team Member"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="staff-grid-layout">
        {staff.map((member) => (
          <div
            key={member.id}
            className="group relative bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 block"
            id={`staff-card-${member.id}`}
          >
            {/* Image section */}
            <div className="h-64 overflow-hidden relative bg-gray-50">
              <img
                src={member.imageUrl}
                alt={member.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 via-transparent to-transparent opacity-90" />
              
              {/* Overlay Staff Identity */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] tracking-widest text-indigo-200 font-bold uppercase bg-indigo-900/60 backdrop-blur-md px-2 py-0.5 rounded-md border border-indigo-800/40">
                  Certified Advisor
                </span>
                <h3 className="text-xl font-bold mt-1 tracking-tight text-white">{member.name}</h3>
                <p className="text-xs text-white/90">{member.role}</p>
              </div>

              {/* Admin Quick Panels */}
              {isAdmin && (
                <div className="absolute top-3 right-3 flex gap-1.5" id={`admin-staff-actions-${member.id}`}>
                  <button
                    onClick={() => handleOpenEdit(member)}
                    className="p-1 px-2.5 rounded-lg bg-white/90 hover:bg-white text-gray-700 hover:text-indigo-600 text-xs font-semibold backdrop-blur-md shadow-sm flex items-center gap-1 transition-colors"
                    title="Edit Member"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Edit
                  </button>
                  <button
                    onClick={() => onDeleteStaff(member.id)}
                    className="p-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white backdrop-blur-md shadow-sm transition-colors"
                    title="Delete Member"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Bio info */}
            <div className="p-5 text-left">
              <p className="text-sm text-gray-650 leading-relaxed italic">
                "{member.bio || "Devoted admission counselor expertised in custom scholarship and documentation portfolios."}"
              </p>
              <div className="mt-4 pt-4 border-t border-gray-50 flex items-center justify-between text-xs text-gray-405 font-medium">
                <span className="inline-flex items-center gap-1 text-indigo-650 font-bold"><Sparkles className="w-3.5 h-3.5" /> Oxford/Toronto Specialist</span>
                <span>Active Advisor</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
