import React, { useState } from "react";
import { User, Application, Country } from "../types";
import { Check, X, FileText, UserCheck, MessageSquarePlus, Activity, ExternalLink, Calendar, PlusCircle, AlertCircle, Image as ImageIcon, Globe } from "lucide-react";

interface AgentPanelProps {
  user: User;
  applications: Application[];
  countries?: Country[];
  onUpdateApplicationStatus: (id: string, status: string, notes: string, screenshot?: string) => Promise<void>;
  onOpenChat: () => void;
}

export default function AgentPanel({ user, applications, countries = [], onUpdateApplicationStatus, onOpenChat }: AgentPanelProps) {
  // Only show applications assigned to this agent and matching their selected specific countries
  const agentCountryIds = user.countries || [];
  const assignedApplications = applications.filter((app) => {
    if (agentCountryIds.length === 0) return app.agentId === user.id;
    return app.agentId === user.id && agentCountryIds.includes(app.countryId);
  });

  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [statusVal, setStatusVal] = useState("");
  const [customStatusText, setCustomStatusText] = useState("");
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [noteText, setNoteText] = useState("");
  const [uploadedScreenshot, setUploadedScreenshot] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);

  // Stats (supports both presets and generic custom statuses seamlessly)
  const initialCount = assignedApplications.filter((a) => a.status === "Request to Agency" || a.status === "Approved by Agency" || a.status === "Application Submitted" || a.status === "Initial Review").length;
  const verifiedCount = assignedApplications.filter((a) => a.status === "First Phase" || a.status === "First Phase Passed" || a.status === "Pre-admission" || a.status === "Getting Pre-admission").length;
  const acceptedCount = assignedApplications.filter((a) => a.status === "Accepted by University" || a.status === "Visa Application").length;

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalStatus = statusVal === "Custom" ? customStatusText.trim() : statusVal;
    if (!selectedAppId || !finalStatus) {
      alert("Please specify or choose a status stage!");
      return;
    }

    setIsUpdating(true);
    try {
      await onUpdateApplicationStatus(selectedAppId, finalStatus, noteText, uploadedScreenshot || undefined);
      setSelectedAppId(null);
      setNoteText("");
      setCustomStatusText("");
      setShowCustomInput(false);
      setUploadedScreenshot("");
      alert("Application status updated with notes & screenshot!");
    } catch (err) {
      console.error(err);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto" id="agent-panel-dashboard">
      <div className="text-left mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
            Assigned Advisor Panel
          </span>
          <h1 className="text-3xl font-extrabold text-gray-950 mt-3 tracking-tight flex items-center gap-1.5">
            <UserCheck className="w-8 h-8 text-indigo-600" /> Agent Case Management
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Review documents, check verification milestones, and write comments for your assigned applicant students.
          </p>
        </div>

        {/* Actions layout wrapper */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Messaging Desk Quick Button */}
          <button
            onClick={onOpenChat}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs px-5 py-3 rounded-2xl flex items-center justify-center gap-2 shadow-sm hover:shadow transition-all cursor-pointer text-left border border-indigo-505"
          >
            <MessageSquarePlus className="w-5 h-5 text-indigo-100 animate-pulse" />
            <div>
              <span className="block text-[10px] font-black uppercase tracking-wider text-indigo-100">Messaging Desk</span>
              <span className="block text-[9px] font-medium opacity-90">Live Chat with Students</span>
            </div>
          </button>

          {/* Selected countries badges list */}
          <div className="bg-slate-50 border border-gray-150 p-4 rounded-2xl flex flex-col gap-1.5 min-w-[200px] text-left">
            <span className="text-[10px] font-extrabold uppercase text-gray-400 tracking-wider flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-indigo-600" /> Authorized Countries ({agentCountryIds.length})
            </span>
            <div className="flex flex-wrap gap-1">
              {agentCountryIds.length === 0 ? (
                <span className="text-[10px] font-extrabold bg-indigo-50 border border-indigo-150 text-indigo-750 px-2.5 py-1 rounded-lg">
                  Universal Work scope
                </span>
              ) : (
                agentCountryIds.map((cid) => {
                  const cFound = countries.find((c) => c.id === cid);
                  return (
                    <span key={cid} className="text-[10px] font-extrabold bg-indigo-50 border border-indigo-150 text-indigo-750 px-2.5 py-1 rounded-lg">
                      {cFound ? cFound.name : cid.toUpperCase()}
                    </span>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Grid of stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" id="agent-stats-grid">
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">Agency & Submission Audit</span>
          <div className="text-2xl font-extrabold text-amber-600 mt-1">{initialCount} Cases</div>
          <p className="text-[10px] text-gray-500 mt-0.5">Approved by Agency, Submitted, Initial Review</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-150 text-left">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">Evaluation & Pre-Admission</span>
          <div className="text-2xl font-extrabold text-indigo-600 mt-1">{verifiedCount} Cases</div>
          <p className="text-[10px] text-gray-500 mt-0.5">First Phase screening & Pre-admission steps</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-155 text-left">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">Accepted & Visa Progression</span>
          <div className="text-2xl font-extrabold text-emerald-600 mt-1">{acceptedCount} Admissions</div>
          <p className="text-[10px] text-gray-500 mt-0.5">Accepted by University and Visa filing stages</p>
        </div>
      </div>

      <div className="bg-white border border-gray-150 rounded-2xl p-6" id="agent-cases-panel">
        <h3 className="text-lg font-extrabold text-gray-950 flex items-center gap-2 pb-4 border-b border-gray-50 text-left">
          <Activity className="w-5 h-5 text-indigo-600" /> Active Student Files Assignee Directory
        </h3>

        {assignedApplications.length === 0 ? (
          <div className="text-center py-12" id="agent-no-cases">
            <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500 font-semibold">No assigned cases mapped under {user.name}.</p>
            <p className="text-xs text-gray-400 mt-1">New submissions from approved students automatically coordinate to you.</p>
          </div>
        ) : (
          <div className="space-y-6 pt-4">
            {assignedApplications.map((app) => (
              <div
                key={app.id}
                className="bg-gray-50/50 border border-gray-150 p-5 rounded-2xl text-left hover:border-indigo-300 transition-colors flex flex-col lg:flex-row justify-between gap-6"
                id={`agent-app-card-${app.id}`}
              >
                {/* Details column */}
                <div className="space-y-3 flex-1">
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div>
                      <h4 className="text-base font-extrabold text-gray-950">{app.studentName}</h4>
                      <p className="text-xs text-indigo-650 font-bold mt-0.5">{app.studentEmail}</p>
                    </div>
                    <div>
                      <span className={`inline-block px-3 py-1 rounded-full font-bold text-[10px] border ${
                        app.status === 'Accepted by University' || app.status === 'Visa Application'
                          ? 'bg-emerald-100 text-emerald-850 border-emerald-300'
                          : app.status === 'Rejected'
                          ? 'bg-red-100 text-red-850 border-red-350'
                          : app.status === 'First Phase' || app.status === 'First Phase Passed' || app.status === 'Pre-admission' || app.status === 'Getting Pre-admission'
                          ? 'bg-purple-100 text-purple-850 border-purple-300'
                          : 'bg-indigo-100 text-indigo-850 border-indigo-300'
                      }`}>
                        Stage: {app.status}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs pt-2 border-t border-gray-100">
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Target University</span>
                      <p className="font-extrabold text-gray-900 mt-0.5">{app.universityName}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{app.countryName}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Degree / Passport ID</span>
                      <p className="font-extrabold text-indigo-900 mt-0.5">{app.program} Degree</p>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">{app.passportNumber}</p>
                    </div>
                  </div>

                  {/* Documents attachment row */}
                  {app.documents.length > 0 && (
                    <div className="bg-white p-3 rounded-xl border border-gray-150 space-y-1.5">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Student Uploads Files</span>
                      <div className="flex flex-wrap gap-2">
                        {app.documents.map((doc, idx) => (
                          <a
                            href={doc.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            key={idx}
                            className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-100 text-indigo-750 font-bold rounded-lg text-xs hover:bg-indigo-100"
                          >
                            <FileText className="w-3.5 h-3.5" /> {doc.name} ({doc.size})
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Notes stream */}
                  {app.notes.length > 0 && (
                    <div className="space-y-2 pt-2">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Advisor Notes Stream</span>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto pr-2">
                        {app.notes.map((note) => (
                          <div key={note.id} className="bg-white border rounded-lg p-2.5 text-xs">
                            <div className="flex justify-between items-center text-[10px] text-gray-400 mb-1">
                              <span className="font-bold text-gray-700">{note.author} ({note.authorRole})</span>
                              <span>{new Date(note.createdAt).toLocaleDateString()}</span>
                            </div>
                            <p className="text-gray-650 leading-relaxed font-medium">{note.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Status action pane */}
                <div className="lg:w-72 shrink-0 border-t lg:border-t-0 lg:border-l border-gray-150 pt-5 lg:pt-0 lg:pl-6 flex flex-col justify-center">
                  {selectedAppId === app.id ? (
                    <form onSubmit={handleUpdateStatus} className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Set Pipeline status</label>
                        <select
                          required
                          value={statusVal}
                          onChange={(e) => {
                            const val = e.target.value;
                            setStatusVal(val);
                            setShowCustomInput(val === "Custom");
                          }}
                          className="w-full text-xs px-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-indigo-600 font-bold text-gray-900"
                        >
                          <option value="Request to Agency">Request to Agency</option>
                          <option value="Approved by Agency">Approved by Agency</option>
                          <option value="Application Submitted">Application Submitted</option>
                          <option value="Initial Review">Initial Review</option>
                          <option value="First Phase">First Phase</option>
                          <option value="First Phase Passed">First Phase Passed</option>
                          <option value="Pre-admission">Pre-admission</option>
                          <option value="Getting Pre-admission">Getting Pre-admission</option>
                          <option value="Accepted by University">Accepted by University</option>
                          <option value="Visa Application">Visa Application</option>
                          <option value="Rejected">Rejected</option>
                          <option value="Custom">Custom Status...</option>
                        </select>
                      </div>

                      {showCustomInput && (
                        <div>
                           <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Enter Custom Status *</label>
                           <input
                             required
                             type="text"
                             value={customStatusText}
                             onChange={(e) => setCustomStatusText(e.target.value)}
                             placeholder="e.g. Pending Document Check..."
                             className="w-full text-xs px-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-indigo-600 font-bold text-gray-950"
                           />
                        </div>
                      )}

                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Portal Screenshot Proof (Optional)</label>
                        <div className="space-y-2">
                          <label className="flex flex-col items-center justify-center border border-dashed border-gray-200 hover:border-indigo-400 rounded-xl p-2.5 cursor-pointer bg-white transition-colors">
                            <div className="flex items-center gap-1.5 text-[10px] text-gray-550 font-bold uppercase">
                              <ImageIcon className="w-4 h-4 text-indigo-500" />
                              {uploadedScreenshot ? "Change Screenshot" : "Choose Screenshot File"}
                            </div>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    if (typeof reader.result === "string") {
                                      setUploadedScreenshot(reader.result);
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                          {uploadedScreenshot && (
                            <div className="relative group rounded-lg overflow-hidden border border-gray-150 bg-gray-50 max-h-24 flex items-center justify-center">
                              <img src={uploadedScreenshot} alt="Pending upload preview" className="max-h-22 w-auto object-contain" referrerPolicy="no-referrer" />
                              <button
                                type="button"
                                onClick={() => setUploadedScreenshot("")}
                                className="absolute top-1 right-1 p-1 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors cursor-pointer"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Add Stage Notes *</label>
                        <textarea
                          required
                          value={noteText}
                          onChange={(e) => setNoteText(e.target.value)}
                          placeholder="Provide steps for verification, next review, or interview date..."
                          rows={2.5}
                          className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                        />
                      </div>

                      <div className="flex gap-2 justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedAppId(null);
                            setUploadedScreenshot("");
                          }}
                          className="px-3 py-1 text-[10px] font-bold bg-white border border-gray-200 rounded-lg text-gray-655"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={isUpdating}
                          className="px-4 py-1 text-[10px] font-extrabold text-white bg-indigo-600 rounded-lg shadow"
                        >
                          {isUpdating ? "Saving..." : "Save Status"}
                        </button>
                      </div>
                    </form>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedAppId(app.id);
                        const presets = ["Request to Agency", "Approved by Agency", "Application Submitted", "Initial Review", "First Phase", "First Phase Passed", "Pre-admission", "Getting Pre-admission", "Accepted by University", "Visa Application", "Rejected"];
                        if (presets.includes(app.status)) {
                          setStatusVal(app.status);
                          setCustomStatusText("");
                          setShowCustomInput(false);
                          setUploadedScreenshot(app.portalScreenshot || "");
                        } else {
                          setStatusVal("Custom");
                          setCustomStatusText(app.status);
                          setShowCustomInput(true);
                          setUploadedScreenshot(app.portalScreenshot || "");
                        }
                      }}
                      className="w-full inline-flex items-center justify-center gap-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-55"
                    >
                      <MessageSquarePlus className="w-4 h-4" /> Transit Stage & Add Note
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
