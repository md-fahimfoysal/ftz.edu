import React, { useState } from "react";
import { Country, User } from "../types";
import { Plus, Trash2, Edit3, Globe, FolderPlus, X, Check, Image as ImageIcon } from "lucide-react";

interface CountrySectionProps {
  countries: Country[];
  user: User | null;
  selectedCountryId: string | null;
  onSelectCountry: (id: string | null) => void;
  onAddCountry: (newCountry: Omit<Country, "id">) => Promise<void>;
  onUpdateCountry: (id: string, updated: Partial<Country>) => Promise<void>;
  onDeleteCountry: (id: string) => Promise<void>;
}

const PRESET_COUNTRY_IMAGES = [
  { name: "United Kingdom", url: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&q=80&w=800" },
  { name: "United States", url: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&q=80&w=800" },
  { name: "Canada", url: "https://images.unsplash.com/photo-1507608869274-d3177c8bb4c7?auto=format&fit=crop&q=80&w=800" },
  { name: "Germany", url: "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&q=80&w=800" },
  { name: "Australia", url: "https://images.unsplash.com/photo-1523482596081-209829bc9353?auto=format&fit=crop&q=80&w=800" },
  { name: "Sweden", url: "https://images.unsplash.com/photo-1509141050519-efbf3e10bdbe?auto=format&fit=crop&q=80&w=800" },
  { name: "Japan", url: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=800" }
];

export default function CountrySection({
  countries,
  user,
  selectedCountryId,
  onSelectCountry,
  onAddCountry,
  onUpdateCountry,
  onDeleteCountry,
}: CountrySectionProps) {
  const isAdmin = user?.role === "admin";
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const handleOpenAdd = () => {
    setName("");
    setDescription("");
    setImageUrl(PRESET_COUNTRY_IMAGES[0].url);
    setIsAdding(true);
    setEditingId(null);
  };

  const handleOpenEdit = (c: Country, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent selecting the country instantly
    setName(c.name);
    setDescription(c.description);
    setImageUrl(c.imageUrl);
    setEditingId(c.id);
    setIsAdding(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingId) {
      await onUpdateCountry(editingId, { name, description, imageUrl });
      setEditingId(null);
    } else {
      await onAddCountry({ name, description, imageUrl });
      setIsAdding(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // avoid trigger select
    if (confirm("Are you sure you want to delete this country? This will keep other resources but clear country category mappings.")) {
      await onDeleteCountry(id);
      if (selectedCountryId === id) {
        onSelectCountry(null);
      }
    }
  };

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto" id="countries-section">
      {/* Title block */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-8">
        <div className="text-left">
          <h2 className="text-2xl font-extrabold text-gray-950 tracking-tight flex items-center gap-2">
            <Globe className="w-6 h-6 text-indigo-600" /> Explore Global Destinations
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            Choose your academic destination to browse fully verified universities and scholarship portfolios.
          </p>
        </div>

        <div className="flex gap-2">
          {selectedCountryId !== null && (
            <button
              onClick={() => onSelectCountry(null)}
              className="text-xs bg-indigo-50 border border-indigo-200 text-indigo-700 px-3 py-1.5 rounded-lg font-bold hover:bg-indigo-100 transition-colors"
              id="clear-filter-btn"
            >
              Clear Filter
            </button>
          )}

          {isAdmin && !isAdding && !editingId && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 font-semibold text-xs text-white px-4 py-2 rounded-xl transition-all shadow-sm"
              id="admin-add-country-button"
            >
              <Plus className="w-3.5 h-3.5" /> Add Country
            </button>
          )}
        </div>
      </div>

      {/* Editor Block */}
      {(isAdding || editingId) && (
        <div className="mb-8 max-w-xl mx-auto bg-gray-50 border border-gray-200 p-5 rounded-2xl shadow-xs text-left" id="country-editor-form">
          <div className="flex justify-between items-center mb-3">
            <h4 className="text-sm font-extrabold uppercase tracking-wider text-gray-700">
              {editingId ? "Update Country File" : "Register Global Destination Country"}
            </h4>
            <button
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
              }}
              className="text-gray-400 hover:text-gray-900 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Country Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Netherlands"
                className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 placeholder:text-gray-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Brief Catchphrase / Description</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Progressive master programs and favorable resident permit options."
                className="w-full text-xs px-3.5 py-2 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 placeholder:text-gray-400"
              />
            </div>

            {/* Banner selector */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-gray-700">Select Image/Banner URL</label>
              
              <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-gray-200">
                <img
                  src={imageUrl || PRESET_COUNTRY_IMAGES[0].url}
                  alt="Preview"
                  className="w-12 h-12 rounded-lg object-cover border border-gray-250 shadow-xs"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 space-y-1.5">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="Enter custom photo URL..."
                    className="w-full text-[11px] px-2 py-1 rounded border border-gray-200 focus:outline-indigo-600 font-medium"
                  />
                  
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <label className="flex items-center gap-1 cursor-pointer text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 px-2 py-1 rounded justify-center transition-colors font-bold">
                      <ImageIcon className="w-3 h-3" />
                      <span>Upload local image</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              if (typeof reader.result === "string") {
                                setImageUrl(reader.result);
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>

                    <div className="flex flex-row gap-1 items-center flex-wrap">
                      <span className="text-[9px] text-gray-400">Presets:</span>
                      {PRESET_COUNTRY_IMAGES.map((item, id) => (
                        <button
                          key={id}
                          type="button"
                          onClick={() => {
                            setName(item.name);
                            setImageUrl(item.url);
                          }}
                          className="text-[9px] px-1.5 py-0.5 rounded bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 cursor-pointer animate-fade-in"
                        >
                          {item.name}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-gray-650 bg-white border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm"
              >
                {editingId ? "Save Updates" : "Create Card"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Country List Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" id="country-grid">
        {/* All Countries virtual trigger card */}
        <div
          onClick={() => onSelectCountry(null)}
          className={`group cursor-pointer text-left relative h-40 rounded-2xl overflow-hidden border transition-all ${
            selectedCountryId === null
              ? "border-indigo-600 ring-2 ring-indigo-500 scale-102"
              : "border-gray-150 hover:-translate-y-1 hover:shadow-lg"
          }`}
          id="country-card-all"
        >
          <img
            src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=400"
            alt="All countries"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950/80 via-gray-950/40 to-transparent" />
          
          <div className="absolute bottom-3 left-3 text-white">
            <h3 className="text-base font-extrabold tracking-tight">Show All Destination Countries</h3>
            <p className="text-[10px] text-white/80 mt-0.5">Explore global programs unfiltered</p>
          </div>
        </div>

        {countries.map((c) => (
          <div
            key={c.id}
            onClick={() => onSelectCountry(c.id)}
            className={`group cursor-pointer text-left relative h-40 rounded-2xl overflow-hidden border transition-all ${
              selectedCountryId === c.id
                ? "border-indigo-600 ring-2 ring-indigo-500 scale-102"
                : "border-gray-150 hover:-translate-y-1 hover:shadow-lg"
            }`}
            id={`country-card-${c.id}`}
          >
            <img
              src={c.imageUrl}
              alt={c.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-950/80 via-gray-950/30 to-transparent" />
            
            {/* Context overlay for name */}
            <div className="absolute bottom-3 left-3 right-3 text-white">
              <h3 className="text-base font-extrabold tracking-tight text-white">{c.name}</h3>
              <p className="text-[10px] text-white/90 line-clamp-2 mt-0.5">{c.description || "Fully approved global universities and scholarship routes."}</p>
            </div>

            {/* Admin adjustments panel */}
            {isAdmin && (
              <div className="absolute top-2.5 right-2.5 flex gap-1 z-10" id={`admin-actions-${c.id}`}>
                <button
                  onClick={(e) => handleOpenEdit(c, e)}
                  className="p-1 px-1.5 rounded-md bg-white/90 hover:bg-white text-gray-700 hover:text-indigo-600 text-[10px] font-bold backdrop-blur-md shadow-xs"
                  title="Edit details"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={(e) => handleDelete(c.id, e)}
                  className="p-1.5 rounded-md bg-red-650 hover:bg-red-700 text-white backdrop-blur-md shadow-xs"
                  title="Remove Country"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
