import React from "react";
import { motion } from "motion/react";
import { University, Country } from "../types";
import { X, ArrowUpRight, Award, Target, Sparkles, BookOpen } from "lucide-react";

interface CountryUniversitiesModalProps {
  country: Country;
  universities: University[];
  onClose: () => void;
  onApply: (uni: University) => void;
}

export default function CountryUniversitiesModal({
  country,
  universities,
  onClose,
  onApply,
}: CountryUniversitiesModalProps) {
  // Filter country specific universities
  const countryUnis = universities.filter((u) => u.countryId === country.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md" id="country-unis-modal-overlay">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.2 }}
        className="bg-white rounded-3xl shadow-2xl border border-gray-100 max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col text-left"
        id="country-unis-modal-content"
      >
        {/* Country Hero Header Banner */}
        <div className="h-52 relative overflow-hidden bg-slate-950 shrink-0">
          <img
            src={country.imageUrl}
            alt={country.name}
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
          
          {/* Close trigger top-right */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/40 hover:bg-black/60 rounded-full text-white transition-all z-10"
            aria-label="Close Universities list"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Details */}
          <div className="absolute bottom-5 left-6 right-6 text-white pb-1">
            <span className="text-xs font-bold uppercase tracking-widest text-indigo-300">Selected Academic Hub</span>
            <h2 className="text-3xl font-black tracking-tight mt-1 animate-fade-in-up text-white">{country.name}</h2>
            <p className="text-sm text-gray-200 mt-1 max-w-xl font-medium line-clamp-2">
              {country.description || "Browse top college paths and fully approved visa programs."}
            </p>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-50/50">
          <div className="mb-4">
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-gray-400">
              Approved Universities in {country.name} ({countryUnis.length})
            </h3>
          </div>

          {countryUnis.length === 0 ? (
            <div className="bg-white border border-gray-150 rounded-2xl py-12 px-4 text-center max-w-md mx-auto my-6" id="empty-country-unis">
              <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-3" />
              <h4 className="text-base font-bold text-gray-900">No Universities Listed</h4>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                We are actively coordinating partnerships in {country.name}. Please check back soon or consult our admission desks.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-4 py-1.5 bg-indigo-650 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors"
              >
                Go Back to Destinations
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="modal-unis-grid">
              {countryUnis.map((uni) => (
                <div
                  key={uni.id}
                  className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col h-full"
                  id={`modal-uni-item-${uni.id}`}
                >
                  <div className="h-32 relative overflow-hidden bg-gray-50">
                    <img
                      src={uni.imageUrl || "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800"}
                      alt={uni.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        e.currentTarget.src = "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800";
                      }}
                    />
                    
                    {/* Seal Badge */}
                    {uni.scholarship?.isFullyFunded && (
                      <div className="absolute top-2.5 right-2.5">
                        <span className="inline-flex items-center gap-0.5 text-[9px] bg-amber-500 text-white font-extrabold px-2 py-0.5 rounded-full shadow">
                          <Sparkles className="w-2.5 h-2.5" /> Fully Funded
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="text-base font-extrabold text-gray-950 leading-snug line-clamp-2">{uni.name}</h4>
                      
                      {/* Degree badges */}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {uni.programs.map((prog, idx) => (
                          <span key={idx} className="text-[9px] px-1.5 py-0.5 bg-indigo-50 border border-indigo-100 font-bold text-indigo-755 rounded">
                            {prog}
                          </span>
                        ))}
                      </div>

                      {/* Fields */}
                      <div className="mt-3">
                        <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider flex items-center gap-1">
                          <Target className="w-3 h-3" /> Specialties
                        </span>
                        <p className="text-[10px] text-gray-655 font-medium mt-0.5 line-clamp-2">
                          {uni.subjects.join(", ")}
                        </p>
                      </div>

                      {/* Scholarship micro highlight */}
                      {uni.scholarship && uni.scholarship.title && (
                        <div className="mt-3 p-2 bg-amber-50/50 rounded-lg border border-amber-100/50 flex gap-1.5 items-start">
                          <Award className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                          <div className="text-[10px]">
                            <span className="font-bold text-amber-900 block truncate">{uni.scholarship.title}</span>
                            <span className="text-amber-700/90">{uni.scholarship.amount}</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Apply Now */}
                    <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between">
                      <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-extrabold">Open Intake</span>
                      <button
                        onClick={() => {
                          onApply(uni);
                          onClose(); // Close country universities view to show the modal application
                        }}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold shadow-xs inline-flex items-center gap-1 transition-all"
                      >
                        Apply Now <ArrowUpRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Area with Clear/Close action */}
        <div className="p-4 border-t border-gray-150 bg-gray-50 shrink-0 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-5 py-2 hover:bg-gray-200 text-gray-700 border border-gray-200 bg-white rounded-xl text-xs font-bold transition-all shadow-xs"
          >
            Close Viewer
          </button>
        </div>
      </motion.div>
    </div>
  );
}
