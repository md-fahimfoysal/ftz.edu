import { useState } from "react";
import { User, Application } from "../types";
import { User as UserIcon, FileSpreadsheet, Image as ImageIcon, CheckCircle, ChevronRight, Activity, ArrowUpRight, HelpCircle, MessagesSquare, X } from "lucide-react";

interface StudentPanelProps {
  user: User;
  applications: Application[];
  onUploadProfilePhoto: (avatarUrl: string) => Promise<void>;
  setActiveTab: (tab: string) => void;
  onOpenChat: () => void;
}

const PROFILE_PRESET_IMAGES = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200"
];

interface StatusMetadata {
  name: string;
  actionLevel: string;
  actor: string;
  description: string;
  colorClass: string;
}

const STATUS_FLOW: Record<string, StatusMetadata> = {
  "Request to Agency": {
    name: "Agency Request",
    actionLevel: "Initial Inquiry File",
    actor: "Admissions Desk Agent",
    description: "Your registration dossier inquiry has been filed at our priority consultancy advisor desk.",
    colorClass: "bg-gray-150 text-gray-850 border-gray-300 font-bold"
  },
  "Approved by Agency": {
    name: "Agency Approval",
    actionLevel: "Agency Appraisal Check",
    actor: "Director of Admissions",
    description: "Your academic profile matches scholarship filters and our agency has officially certified your registration documents.",
    colorClass: "bg-amber-50 text-amber-850 border-amber-250 font-bold"
  },
  "Application Submitted": {
    name: "Dossier Lodged",
    actionLevel: "Intake Submission",
    actor: "Assigned Advisor",
    description: "Your full application file has been dispatched and successfully lodged at the university's priority admissions portal.",
    colorClass: "bg-indigo-50 text-indigo-850 border-indigo-250 font-bold"
  },
  "Initial Review": {
    name: "Initial review",
    actionLevel: "Registry Assessment",
    actor: "Faculty Evaluator",
    description: "Admissions is carrying out deep review of transcript scores, subject suitability, and language scores.",
    colorClass: "bg-blue-50 text-blue-850 border-blue-250 font-bold"
  },
  "First Phase": {
    name: "First Phase",
    actionLevel: "Interview Stage",
    actor: "Faculty Board",
    description: "Scheduled for primary motivation assessment. Ensure stable internet and audio for the video call.",
    colorClass: "bg-purple-50 text-purple-855 border-purple-255 font-bold"
  },
  "First Phase Passed": {
    name: "Phase Passed",
    actionLevel: "Screening Approval",
    actor: "Faculty Panel",
    description: "Outstanding result! You advanced to the secondary university nomination list. Seat allocation pending.",
    colorClass: "bg-violet-50 text-violet-850 border-violet-250 font-bold"
  },
  "Pre-admission": {
    name: "Pre-admission",
    actionLevel: "Provisional Offer",
    actor: "Registrar Deputy",
    description: "Secured provisional pre-admission candidacy. Confirming local seat-acceptance checklist files.",
    colorClass: "bg-teal-50 text-teal-850 border-teal-250 font-bold"
  },
  "Getting Pre-admission": {
    name: "Getting Pre-admission",
    actionLevel: "Offer Ledger Check",
    actor: "Scholarship Sponsor",
    description: "Issuing scholarship certifications and finalizing your pre-admission register ledger on the cloud database.",
    colorClass: "bg-cyan-50 text-cyan-850 border-cyan-250 font-bold"
  },
  "Accepted by University": {
    name: "Accepted by Uni",
    actionLevel: "Final Unconditional Letter",
    actor: "Rector / Board of Governors",
    description: "Congratulations! Your official Offer Letter and Scholarship Certificate have been issued.",
    colorClass: "bg-emerald-50 text-emerald-850 border-emerald-250 font-bold"
  },
  "Visa Application": {
    name: "Visa Stage",
    actionLevel: "Embassy Consular Filing",
    actor: "Consular Desk Guide",
    description: "Preparing study visa packets, medical certificates, and scheduling high-commissioner biometric appointments.",
    colorClass: "bg-indigo-100 text-indigo-950 border-indigo-300 font-bold"
  },
  "Rejected": {
    name: "Refused",
    actionLevel: "Account Suspended",
    actor: "Intake Senate of Admissions",
    description: "Unfortunately, academic matching failed to resolve admission clearances. Ask advisor for profile re-filings.",
    colorClass: "bg-red-50 text-red-850 border-red-250 font-bold"
  }
};

export default function StudentPanel({ user, applications, onUploadProfilePhoto, setActiveTab, onOpenChat }: StudentPanelProps) {
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [customPhotoUrl, setCustomPhotoUrl] = useState("");
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const studentApplications = applications.filter((app) => app.studentId === user.id);

  // Profile photo upload simulation
  const handleUploadPhoto = async (photoUrl: string) => {
    setIsUploadingPhoto(true);
    try {
      await onUploadProfilePhoto(photoUrl);
      alert("Profile picture successfully configured!");
    } catch (err) {
      console.error(err);
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const getStatusMetadata = (status: string): StatusMetadata => {
    return STATUS_FLOW[status] || {
      name: status,
      actionLevel: "Custom Pipeline Update",
      actor: "Designated Advisor Team",
      description: "Admissions advisors updated your current status to: " + status + ". Please check advisor comments.",
      colorClass: "bg-gray-50 text-gray-800 border-gray-200"
    };
  };

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto" id="student-panel-dashboard">
      {/* Title block */}
      <div className="text-left mb-8 flex flex-col md:flex-row md:justify-between md:items-end gap-4 pb-6 border-b border-gray-100">
        <div>
          <span className="text-xs font-bold uppercase text-emerald-600 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
            Active Student Applicant
          </span>
          <h1 className="text-3xl font-extrabold text-gray-950 mt-3 tracking-tight">
            Welcome, {user.name}!
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Track registration pipelines, review agent comments, and manage your visa portfolio details.
          </p>
        </div>

        {/* Action helper */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={onOpenChat}
            className="inline-flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 font-extrabold text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
          >
            <MessagesSquare className="w-4 h-4 text-indigo-600 animate-pulse" /> Open Messenger Portal
          </button>
          <button
            onClick={() => setActiveTab("home")}
            className="inline-flex items-center gap-1 bg-indigo-600 hover:bg-indigo-755 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
          >
            Submit Secondary Application <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="student-grid">
        {/* Profile Info card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white border border-gray-150 rounded-2xl p-6 text-left" id="student-profile-card">
            <h3 className="text-lg font-extrabold text-gray-950 flex items-center gap-1.5 pb-3 border-b border-gray-100">
              <UserIcon className="w-5 h-5 text-indigo-600" /> Account Profile Info
            </h3>

            {/* Profile Avatar section */}
            <div className="flex flex-col items-center py-6">
              <img
                src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"}
                alt={user.name}
                className="w-24 h-24 rounded-full object-cover border-4 border-indigo-100 shadow-md mb-4"
                referrerPolicy="no-referrer"
              />

              {/* Avatar options upload */}
              <div className="space-y-3 w-full text-center">
                <span className="text-[10px] text-gray-400 font-bold uppercase block">Choose Profile Preset Standard:</span>
                
                <div className="flex justify-center gap-2">
                  {PROFILE_PRESET_IMAGES.map((preset, i) => (
                    <button
                      key={i}
                      onClick={() => handleUploadPhoto(preset)}
                      disabled={isUploadingPhoto}
                      className="w-7 h-7 rounded-full overflow-hidden border-2 border-transparent hover:border-indigo-650"
                    >
                      <img src={preset} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </button>
                  ))}
                </div>

                <div className="pt-2 border-t border-gray-100 space-y-2">
                  <label className="block text-[10px] text-gray-550 font-bold uppercase">Upload Custom Photo:</label>
                  <label className="flex flex-col items-center justify-center border-2 border-dashed border-gray-200 hover:border-indigo-500 rounded-xl p-3 cursor-pointer transition-colors bg-gray-50/50 hover:bg-indigo-50/10">
                    <ImageIcon className="w-5 h-5 text-gray-400 mb-1" />
                    <span className="text-[10px] text-gray-600 font-semibold">Select local image file</span>
                    <span className="text-[8px] text-gray-400 font-medium">JPEG, PNG or WEBP</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === "string") {
                              handleUploadPhoto(reader.result);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>

                  <div className="pt-1 flex flex-col gap-1">
                    <span className="text-[9px] text-gray-450 uppercase font-bold">Or paste custom secure web URL:</span>
                    <div className="flex gap-1">
                      <input
                        type="text"
                        placeholder="Enter secure Web URL..."
                        value={customPhotoUrl}
                        onChange={(e) => setCustomPhotoUrl(e.target.value)}
                        className="w-full text-[10px] px-2 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-900 focus:outline-hidden focus:border-indigo-500 font-medium"
                      />
                      <button
                        onClick={() => {
                          if (customPhotoUrl.trim()) handleUploadPhoto(customPhotoUrl);
                        }}
                        className="p-1 px-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Set
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-100 text-xs text-gray-650 font-semibold" id="student-profile-details">
              <div>
                <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Student applicant email</span>
                <span className="text-gray-900 mt-0.5 block truncate font-mono">{user.email}</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Access Status</span>
                  <span className="inline-block mt-1 text-[10px] bg-emerald-50 border border-emerald-200 text-emerald-800 px-2 py-0.5 rounded font-bold uppercase">
                    Admin Approved
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Role Type</span>
                  <span className="inline-block mt-1 text-[10px] bg-indigo-50 border border-indigo-200 text-indigo-800 px-2 py-0.5 rounded font-bold uppercase">
                    Student
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Active tracker column */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-gray-150 rounded-2xl p-6 text-left" id="student-trackers">
            <h3 className="text-lg font-extrabold text-gray-950 flex items-center justify-between pb-3 border-b border-gray-100 mb-6">
              <span className="flex items-center gap-1.5"><Activity className="w-5 h-5 text-indigo-600" /> Real-time Application Trackers ({studentApplications.length})</span>
            </h3>

            {studentApplications.length === 0 ? (
              <div className="text-center py-12" id="student-no-applications">
                <FileSpreadsheet className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-gray-500 font-extrabold">You haven't initiated any application profiles yet!</p>
                <p className="text-xs text-gray-400 mt-1">
                  Navigate our global universities list on the homepage and click the "Apply" trigger.
                </p>
              </div>
            ) : (
              <div className="space-y-8">
                {studentApplications.map((app) => {
                  const meta = getStatusMetadata(app.status);
                  return (
                    <div
                      key={app.id}
                      className="bg-gray-50/55 border border-gray-200 p-5 rounded-2xl space-y-4"
                      id={`student-app-tracker-${app.id}`}
                    >
                      {/* Summary item */}
                      <div className="flex justify-between items-start flex-wrap gap-2 pb-3 border-b border-gray-150">
                        <div>
                          <h4 className="text-base font-extrabold text-gray-900">{app.universityName}</h4>
                          <span className="text-xs text-gray-400">{app.countryName} • {app.program} portfolio</span>
                        </div>

                        <div>
                          {app.status === 'Accepted by University' ? (
                            <span className="inline-flex items-center gap-0.5 px-3 py-1 font-bold text-[10px] bg-emerald-100 text-emerald-800 rounded-full border border-emerald-300">
                              Admissions Approved
                            </span>
                          ) : app.status === 'Rejected' ? (
                            <span className="inline-flex items-center gap-0.5 px-3 py-1 font-bold text-[10px] bg-red-100 text-red-800 rounded-full border border-red-350">
                              Portfolios Closed
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-0.5 px-3 py-1 font-bold text-[10px] bg-indigo-50 text-indigo-800 rounded-full border border-indigo-250">
                              Pipeline: {app.status}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Timeline Workflow Visualizer */}
                      <div className="py-2 space-y-4">
                        <div className="bg-white p-4 rounded-xl border border-gray-150 text-left relative overflow-hidden">
                          <div className="absolute right-0 top-0 w-24 h-24 bg-indigo-50 rounded-full blur-2xl opacity-40 pointer-events-none" />
                          <div className="flex justify-between items-center mb-1.5">
                            <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Active Pipeline Stage</span>
                            <span className={`text-[10px] px-2.5 py-0.5 rounded font-black border ${meta.colorClass}`}>
                              {app.status}
                            </span>
                          </div>
                          
                          <h5 className="text-sm font-extrabold text-indigo-950 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-pulse shrink-0" />
                            {meta.actionLevel}
                          </h5>

                          <div className="mt-3.5 grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-100 pt-3.5 text-xs text-gray-650">
                            <div>
                              <span className="text-[10px] text-gray-400 font-bold uppercase block mb-0.5">Responsible Desk Partner</span>
                              <p className="font-extrabold text-gray-800">{meta.actor}</p>
                            </div>
                            <div>
                              <span className="text-[10px] text-gray-400 font-bold uppercase block mb-0.5">Current Status Directive</span>
                              <p className="text-gray-650 font-medium leading-normal">{meta.description}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Portal Screenshot evidence if available */}
                      {app.portalScreenshot && (
                        <div className="bg-white p-4 rounded-xl border border-gray-150 text-left">
                          <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                            <ImageIcon className="w-3.5 h-3.5 text-indigo-600" /> Portal Update Screenshot Proof
                          </span>
                          <div className="relative group overflow-hidden rounded-xl border border-gray-150 bg-gray-50 max-h-56 flex justify-center items-center cursor-zoom-in" onClick={() => setZoomedImage(app.portalScreenshot || null)}>
                            <img
                              src={app.portalScreenshot}
                              alt="Portal Update Screenshot"
                              className="max-h-56 w-auto object-contain transition-all duration-200 hover:scale-[1.02]"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                              <span className="bg-black/75 text-white text-[10px] font-extrabold px-3 py-1.5 rounded-xl shadow">Click to expand portal snapshot</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Documents Audited file links */}
                      {app.documents.length > 0 && (
                        <div className="bg-white p-3 rounded-xl border border-gray-150 text-left">
                          <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-2">My Audited Portfolios</span>
                          <div className="flex flex-wrap gap-2">
                            {app.documents.map((doc, idx) => (
                              <a
                                key={idx}
                                href={doc.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-gray-50 border border-gray-150 text-gray-750 font-bold rounded-lg text-[10px] hover:bg-gray-100"
                              >
                                <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-500" /> {doc.name}
                              </a>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Comments and status updates stream */}
                      <div className="bg-white p-4 rounded-xl border border-gray-150 text-left">
                        <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-3 flex items-center gap-1">
                          <MessagesSquare className="w-3.5 h-3.5" /> Comments from admission advisors ({app.notes.length})
                        </span>

                        {app.notes.length === 0 ? (
                          <div className="text-xs text-gray-400 italic">No feedback messages yet. Your advisor is auditing details.</div>
                        ) : (
                          <div className="space-y-3 max-h-40 overflow-y-auto pr-1">
                            {app.notes.map((note) => (
                              <div key={note.id} className="bg-gray-50/50 p-2.5 rounded-lg text-xs leading-relaxed border border-gray-100">
                                <div className="flex justify-between text-[9px] text-gray-400 mb-1 font-bold">
                                  <span>{note.author} ({note.authorRole})</span>
                                  <span>{new Date(note.createdAt).toLocaleDateString()}</span>
                                </div>
                                <p className="text-gray-700 font-semibold">{note.text}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    
      {/* Zoomed portal screenshot Modal overlay */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs transition-opacity"
          onClick={() => setZoomedImage(null)}
          id="screenshot-zoom-modal"
        >
          <div
            className="relative bg-white rounded-2xl shadow-2xl max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-4 py-3 border-b border-gray-150">
              <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-indigo-600" /> Portal Screenshot Evidence
              </span>
              <button
                onClick={() => setZoomedImage(null)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-auto p-4 flex items-center justify-center bg-gray-50 max-h-[80vh]">
              <img
                src={zoomedImage}
                alt="Zoomed Screenshot Evidence"
                className="max-w-full max-h-[70vh] object-contain rounded-lg border border-gray-200"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
