import React, { useState, useEffect, useRef } from "react";
import { User, Conversation, Message, MessageAttachment } from "../types";
import {
  Search,
  Send,
  Paperclip,
  Smile,
  Check,
  CheckCheck,
  User as UserIcon,
  FileText,
  Download,
  UserPlus,
  ArrowLeft,
  Moon,
  Sun,
  X,
  FileDown,
  Loader2,
  CheckCheck as SeenIcon,
  CornerDownLeft,
  Trash2
} from "lucide-react";

interface MessengerProps {
  currentUser: User;
  onClose?: () => void;
  // Shared WebSockets and presence states
  socket: WebSocket | null;
  onlineUserIds: string[];
}

const POPULAR_EMOJIS = [
  "😀", "😂", "🥰", "😍", "😘", "😜", "😎", "🤔", "😴", "😭", 
  "👍", "👎", "👏", "🔥", "🎉", "❤️", "💖", "✨", "🙌", "💡"
];

export default function Messenger({ currentUser, onClose, socket, onlineUserIds }: MessengerProps) {
  // Theme configuration
  const [isDarkMode, setIsDarkMode] = useState(false);

  // States
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConv, setActiveConv] = useState<any | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  
  // Directory modal / view
  const [showDirectory, setShowDirectory] = useState(false);
  const [directoryUsers, setDirectoryUsers] = useState<any[]>([]);
  const [directorySearch, setDirectorySearch] = useState("");
  
  // Typing indicator
  const [typingUsers, setTypingUsers] = useState<Record<string, boolean>>({});
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef<any>(null);

  // Emoji picker toggle
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // File Upload state
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Refs
  const messageEndRef = useRef<HTMLDivElement>(null);

  // Fetch conversations on load
  const fetchConversations = async () => {
    try {
      const res = await fetch(`/api/chat/conversations?userId=${currentUser.id}`);
      if (res.ok) {
        const data = await res.json();
        setConversations(data);
        
        // If there's an active conversation, preserve or update it
        if (activeConv) {
          const updatedActive = data.find((c: any) => c.id === activeConv.id);
          if (updatedActive) {
            setActiveConv(updatedActive);
          } else {
            setActiveConv(null);
            setMessages([]);
          }
        }
      }
    } catch (err) {
      console.error("Error fetching conversations:", err);
    }
  };

  useEffect(() => {
    fetchConversations();
    // Refresh conversations occasionally to sync presence / unread counters
    const interval = setInterval(fetchConversations, 8000);
    return () => clearInterval(interval);
  }, [currentUser.id, activeConv?.id]);

  // Fetch messages when active conversation changes
  useEffect(() => {
    if (!activeConv) return;
    
    const fetchMessages = async () => {
      try {
        const res = await fetch(`/api/chat/conversations/${activeConv.id}/messages`);
        if (res.ok) {
          const data = await res.json();
          setMessages(data);
          
          // Mark messages as seen
          markConversationAsSeen(activeConv.id);
        }
      } catch (err) {
        console.error("Error fetching messages:", err);
      }
    };

    fetchMessages();
  }, [activeConv?.id]);

  // Poll for new messages as fallback when WebSocket is not available or connected
  useEffect(() => {
    if (!activeConv) return;

    const pollInterval = setInterval(() => {
      if (!socket || socket.readyState !== WebSocket.OPEN) {
        const fetchMessagesSilently = async () => {
          try {
            const res = await fetch(`/api/chat/conversations/${activeConv.id}/messages`);
            if (res.ok) {
              const data = await res.json();
              setMessages(prev => {
                // If length and last message are identical, preserve reference to prevent flashing/re-renders
                if (prev.length === data.length && prev[prev.length - 1]?.id === data[data.length - 1]?.id) {
                  return prev;
                }
                return data;
              });
            }
          } catch (err) {
            console.log("Polling active messages deferred:", err);
          }
        };
        fetchMessagesSilently();
      }
    }, 4000);

    return () => clearInterval(pollInterval);
  }, [activeConv?.id, socket]);

  // Handle auto scroll
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typingUsers]);

  // Listen to WebSocket messages
  useEffect(() => {
    if (!socket) return;

    const handleSocketMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === "message") {
          const msg = data.message as Message;
          // If message belongs to active conversation, append it
          if (activeConv && msg.conversationId === activeConv.id) {
            setMessages(prev => {
              if (prev.some(m => m.id === msg.id)) return prev;
              return [...prev, msg];
            });
            // Mark as seen immediately
            markConversationAsSeen(activeConv.id);
          }
          fetchConversations();
        } else if (data.type === "seen") {
          if (activeConv && data.conversationId === activeConv.id) {
            setMessages(prev => prev.map(m => m.senderId === data.userId ? m : { ...m, seen: true }));
          }
        } else if (data.type === "typing") {
          if (activeConv && data.conversationId === activeConv.id) {
            setTypingUsers(prev => ({ ...prev, [data.senderId]: data.isTyping }));
          }
        } else if (data.type === "presence") {
          // fetchConversations(); (Disabled to prevent endless loading/blinking due to reconnects)
        } else if (data.type === "conversation_deleted") {
          if (activeConv && activeConv.id === data.conversationId) {
            setActiveConv(null);
            setMessages([]);
          }
          fetchConversations();
        } else if (data.type === "message_deleted") {
          if (activeConv && activeConv.id === data.conversationId) {
            setMessages(prev => prev.filter(m => m.id !== data.messageId));
          }
          fetchConversations();
        }
      } catch (err) {
        console.error("Error parsing WS event in Messenger:", err);
      }
    };

    socket.addEventListener("message", handleSocketMessage);
    return () => socket.removeEventListener("message", handleSocketMessage);
  }, [socket, activeConv?.id]);

  // Mark conversation as seen
  const markConversationAsSeen = async (convId: string) => {
    try {
      await fetch(`/api/chat/conversations/${convId}/seen`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUser.id })
      });
      
      // Also send seen event over WebSocket
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
          type: "seen",
          conversationId: convId,
          userId: currentUser.id
        }));
      }
      
      // Update local unread counter
      setConversations(prev => prev.map(c => c.id === convId ? { ...c, unreadCount: 0 } : c));
    } catch (err) {
      console.error("Error marking seen:", err);
    }
  };

  // Handle Sending Messages
  const handleSendMessage = async (textToSend?: string, attachmentToSend?: MessageAttachment) => {
    const finalVal = textToSend !== undefined ? textToSend : inputMessage;
    if (!finalVal.trim() && !attachmentToSend) return;
    if (!activeConv) return;

    const payload = {
      conversationId: activeConv.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      text: finalVal,
      attachment: attachmentToSend
    };

    try {
      const res = await fetch("/api/chat/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const newMsg = await res.json();
        // Always append sent message immediately to guarantee it shows instantly without delays or WebSocket drops
        setMessages(prev => {
          if (prev.some(m => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
        setInputMessage("");
        setShowEmojiPicker(false);
        
        // Update typing off
        sendTypingStatus(false);
        
        // Refresh conversations to show latest lastMessage
        fetchConversations();
      }
    } catch (err) {
      console.error("Error sending message:", err);
    }
  };

  // Typing status sender
  const sendTypingStatus = (typing: boolean) => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !activeConv) return;
    socket.send(JSON.stringify({
      type: "typing",
      conversationId: activeConv.id,
      senderId: currentUser.id,
      isTyping: typing
    }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputMessage(e.target.value);
    
    if (!isTyping) {
      setIsTyping(true);
      sendTypingStatus(true);
    }

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      sendTypingStatus(false);
    }, 2000);
  };

  // Directory users fetching
  const loadDirectoryUsers = async () => {
    try {
      const res = await fetch(`/api/chat/users?userId=${currentUser.id}&role=${currentUser.role}`);
      if (res.ok) {
        const data = await res.json();
        setDirectoryUsers(data);
        setShowDirectory(true);
      }
    } catch (err) {
      console.error("Error loading chat directory:", err);
    }
  };

  // Start new conversation
  const startConversation = async (otherUser: any) => {
    try {
      const res = await fetch("/api/chat/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          participants: [currentUser.id, otherUser.id]
        })
      });

      if (res.ok) {
        const conv = await res.json();
        // Enrich it with otherParticipant
        const enrichedConv = {
          ...conv,
          otherParticipants: [otherUser],
          unreadCount: 0
        };
        setActiveConv(enrichedConv);
        setShowDirectory(false);
        fetchConversations();
      }
    } catch (err) {
      console.error("Error starting conversation:", err);
    }
  };

  // Emoji Click
  const insertEmoji = (emoji: string) => {
    setInputMessage(prev => prev + emoji);
  };

  // Delete full conversation history (Admin only)
  const handleDeleteConversation = async (convId: string) => {
    if (confirmDeleteId !== convId) {
      setConfirmDeleteId(convId);
      // Automatically reset confirmation after 4 seconds of inactivity
      setTimeout(() => {
        setConfirmDeleteId(prev => prev === convId ? null : prev);
      }, 4000);
      return;
    }
    
    try {
      const res = await fetch(`/api/chat/conversations/${convId}?adminId=${currentUser.id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        setConfirmDeleteId(null);
        setActiveConv(null);
        setMessages([]);
        fetchConversations();
      } else {
        const data = await res.json();
        alert(data.error || "Failed to delete conversation.");
      }
    } catch (err) {
      console.error("Error deleting conversation:", err);
    }
  };

  // Delete an individual message (Admin or Sender)
  const handleDeleteMessage = async (msgId: string) => {
    if (!window.confirm("Are you sure you want to delete this message? This action is permanent and will delete it for everyone.")) {
      return;
    }
    try {
      const res = await fetch(`/api/chat/messages/${msgId}?userId=${currentUser.id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        setMessages(prev => prev.filter(m => m.id !== msgId));
        fetchConversations();
      } else {
        const data = await res.json();
        alert(data.error || "Failed to delete message.");
      }
    } catch (err) {
      console.error("Error deleting message:", err);
    }
  };

  // Upload File handler
  const handleFileUpload = async (file: File) => {
    if (!file) return;
    setIsUploading(true);

    try {
      // Read file to Base64
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = reader.result as string;
        
        const uploadRes = await fetch("/api/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fileName: file.name,
            base64Data
          })
        });

        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();
          
          // Determine file category (image, doc, pdf, etc)
          let fileType = "document";
          if (file.type.startsWith("image/")) {
            fileType = "image";
          } else if (file.type === "application/pdf") {
            fileType = "pdf";
          }

          const sizeStr = (file.size / (1024 * 1024)).toFixed(2) + " MB";

          const attachment: MessageAttachment = {
            name: file.name,
            url: uploadData.url,
            size: sizeStr,
            type: fileType
          };

          // Send attachment message
          await handleSendMessage(`Shared a file: ${file.name}`, attachment);
        } else {
          alert("Failed to upload the file to storage.");
        }
        setIsUploading(false);
      };
    } catch (err) {
      console.error("Error during attachment transfer:", err);
      setIsUploading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Formatting dates
  const formatTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return "";
    }
  };

  const formatDateLabel = (isoString: string) => {
    try {
      const d = new Date(isoString);
      const today = new Date();
      const yesterday = new Date();
      yesterday.setDate(today.getDate() - 1);

      if (d.toDateString() === today.toDateString()) {
        return "Today";
      } else if (d.toDateString() === yesterday.toDateString()) {
        return "Yesterday";
      } else {
        return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
      }
    } catch {
      return "";
    }
  };

  // Filters Conversations based on search
  const filteredConvs = conversations.filter(c => {
    const otherParticipant = c.otherParticipants?.[0];
    if (!otherParticipant) return false;
    return otherParticipant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           otherParticipant.role.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Filters Directory Contacts
  const filteredDirectoryUsers = directoryUsers.filter(u => 
    u.name.toLowerCase().includes(directorySearch.toLowerCase()) ||
    u.role.toLowerCase().includes(directorySearch.toLowerCase())
  );

  return (
    <div 
      className={`h-[680px] w-full flex rounded-2xl overflow-hidden border shadow-xl transition-colors duration-250 ${
        isDarkMode 
          ? "bg-[#0b141a] border-[#2f3b43] text-gray-100" 
          : "bg-white border-[#e9edef] text-gray-900"
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      id="messenger-main-container"
    >
      {/* File Upload drag cover overlay */}
      {dragOver && (
        <div className="absolute inset-0 bg-[#00a884]/10 backdrop-blur-[2px] border-4 border-dashed border-[#00a884] z-50 flex items-center justify-center rounded-2xl pointer-events-none">
          <div className="bg-white px-6 py-4 rounded-xl shadow-lg flex items-center gap-3">
            <Paperclip className="w-6 h-6 text-[#00a884] animate-bounce" />
            <span className="text-sm font-bold text-gray-900">Drop your file to send attachment</span>
          </div>
        </div>
      )}

      {/* Left side: Conversation List Panel */}
      <div className={`w-80 flex flex-col border-r h-full flex-shrink-0 ${
        isDarkMode ? "border-[#222e35] bg-[#111b21]" : "border-[#e9edef] bg-white"
      }`}>
        {/* Header toolbar */}
        <div className={`p-4 border-b flex items-center justify-between gap-2 border-inherit ${
          isDarkMode ? "bg-[#202c33]" : "bg-[#f0f2f5]"
        }`}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#00a884] text-white flex items-center justify-center font-extrabold text-sm uppercase shadow-xs">
              {currentUser.name.substring(0, 2)}
            </div>
            <div className="text-left">
              <div className="text-xs font-bold truncate max-w-[120px]">{currentUser.name}</div>
              <div className="text-[9px] font-extrabold tracking-wider text-[#00a884] uppercase">{currentUser.role}</div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)} 
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isDarkMode ? "text-amber-400 hover:bg-[#2a3942]" : "text-gray-500 hover:bg-gray-200"
              }`}
              title="Toggle Messenger Theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button 
              onClick={loadDirectoryUsers}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isDarkMode ? "text-emerald-400 hover:bg-[#2a3942]" : "text-[#00a884] hover:bg-[#00a884]/10"
              }`}
              title="Start New Conversation"
            >
              <UserPlus className="w-4 h-4" />
            </button>
            {onClose && (
              <button 
                onClick={onClose}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isDarkMode ? "text-red-400 hover:bg-[#2a3942]" : "text-red-500 hover:bg-red-50"
                }`}
                title="Exit Messenger"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Conversation List search */}
        <div className="p-3 border-b border-inherit bg-inherit">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border-none focus:outline-none focus:ring-0 ${
                isDarkMode 
                  ? "bg-[#202c33] placeholder-[#8696a0] text-white" 
                  : "bg-[#f0f2f5] placeholder-[#667781] text-gray-900"
              }`}
            />
          </div>
        </div>

        {/* Conversations or loading list */}
        <div className="flex-1 overflow-y-auto divide-y border-inherit divide-inherit">
          {showDirectory ? (
            /* Directory list */
            <div className="p-2 space-y-1 bg-inherit">
              <div className="flex items-center justify-between p-2 pb-1 border-b border-inherit">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#00a884]">New Conversation</span>
                <button 
                  onClick={() => setShowDirectory(false)} 
                  className="text-[10px] font-bold text-red-500 hover:underline cursor-pointer"
                >
                  Back to active
                </button>
              </div>
              <div className="p-1.5">
                <input
                  type="text"
                  placeholder="Filter contacts..."
                  value={directorySearch}
                  onChange={(e) => setDirectorySearch(e.target.value)}
                  className={`w-full text-[11px] px-2.5 py-1 rounded-lg border-none focus:outline-none focus:ring-0 ${
                    isDarkMode 
                      ? "bg-[#202c33] text-white placeholder-[#8696a0]" 
                      : "bg-[#f0f2f5] text-gray-900 placeholder-[#667781]"
                  }`}
                />
              </div>
              {filteredDirectoryUsers.length === 0 ? (
                <div className="text-center py-6 text-xs text-gray-400 italic">No contacts available to chat</div>
              ) : (
                filteredDirectoryUsers.map((u) => {
                  const isUserOnline = (u.role !== "admin" && u.role !== "agent") && onlineUserIds.includes(u.id);
                  return (
                    <button
                      key={u.id}
                      onClick={() => startConversation(u)}
                      className={`w-full text-left p-2.5 rounded-xl transition-all duration-150 flex items-center gap-2.5 cursor-pointer ${
                        isDarkMode ? "hover:bg-[#202c33]" : "hover:bg-gray-100/50"
                      }`}
                    >
                      <div className="relative">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-[#00a884]/10 flex items-center justify-center border border-[#e9edef] dark:border-[#222e35]">
                          {u.avatarUrl ? (
                            <img src={u.avatarUrl} alt={u.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <span className="font-extrabold text-xs text-[#00a884] uppercase">{u.name.substring(0, 2)}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold truncate">{u.name}</div>
                        <div className="text-[10px] text-[#00a884] uppercase font-black">{u.role}</div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          ) : (
            /* Regular conversation list */
            filteredConvs.length === 0 ? (
              <div className="text-center py-12 text-xs text-gray-400 italic">
                {searchTerm ? "No chats found matching filters" : "Start your first chat by clicking the plus icon above!"}
              </div>
            ) : (
              filteredConvs.map((conv) => {
                const otherParticipant = conv.otherParticipants?.[0];
                if (!otherParticipant) return null;
                const isUserOnline = (otherParticipant.role !== "admin" && otherParticipant.role !== "agent" && !otherParticipant.role.includes("Admin Monitor")) && onlineUserIds.includes(otherParticipant.id);
                const isActive = activeConv?.id === conv.id;

                return (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConv(conv)}
                    className={`w-full text-left p-3.5 transition-all duration-150 flex items-start gap-3 border-b cursor-pointer ${
                      isActive 
                        ? (isDarkMode ? "bg-[#2a3942]" : "bg-[#f0f2f5]") 
                        : (isDarkMode ? "hover:bg-[#202c33] bg-transparent" : "hover:bg-gray-50 bg-transparent")
                    } ${isDarkMode ? "border-[#222e35]" : "border-[#f0f2f5]"}`}
                  >
                    <div className="relative flex-shrink-0 mt-0.5">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-[#00a884]/10 flex items-center justify-center border border-[#e9edef] dark:border-[#222e35]">
                        {otherParticipant.avatarUrl ? (
                          <img src={otherParticipant.avatarUrl} alt={otherParticipant.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <span className="font-bold text-sm text-[#00a884] uppercase">{otherParticipant.name.substring(0, 2)}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0 text-left">
                      <div className="flex justify-between items-baseline gap-1">
                        <span className="text-xs font-bold truncate">{otherParticipant.name}</span>
                        {conv.lastMessageTimestamp && (
                          <span className="text-[9px] text-[#667781] dark:text-[#8696a0] font-medium">
                            {formatTime(conv.lastMessageTimestamp)}
                          </span>
                        )}
                      </div>

                      <div className="text-[9px] text-[#00a884] uppercase tracking-wide font-black mt-0.5">
                        {otherParticipant.role}
                      </div>

                      <div className="flex justify-between items-center gap-1.5 mt-1">
                        <p className={`text-[11px] truncate flex-1 ${
                          conv.unreadCount > 0 
                            ? "font-extrabold text-[#25d366]" 
                            : "text-[#667781] dark:text-[#8696a0]"
                        }`}>
                          {conv.lastMessageText || "No messages yet"}
                        </p>
                        
                        {conv.unreadCount > 0 && (
                          <span className="bg-[#25d366] text-white font-black text-[9px] rounded-full min-w-4.5 h-4.5 px-1 flex items-center justify-center shadow-xs">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )
          )}
        </div>
      </div>

      {/* Right side: Chat Window Panel */}
      <div className={`flex-1 flex flex-col h-full ${
        isDarkMode ? "bg-[#0b141a]" : "bg-[#efeae2]"
      }`}>
        {activeConv ? (
          <>
            {/* Selected Chat Header */}
            <div className={`p-3.5 border-b flex items-center justify-between border-inherit ${
              isDarkMode ? "bg-[#202c33]" : "bg-[#f0f2f5]"
            }`}>
              {(() => {
                const other = activeConv.otherParticipants?.[0];
                if (!other) return null;
                const isOnline = (other.role !== "admin" && other.role !== "agent" && !other.role.includes("Admin Monitor")) && onlineUserIds.includes(other.id);

                return (
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-[#00a884]/10 flex items-center justify-center border border-[#e9edef] dark:border-[#222e35]">
                        {other.avatarUrl ? (
                          <img src={other.avatarUrl} alt={other.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <span className="font-bold text-sm text-[#00a884] uppercase">{other.name.substring(0, 2)}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-bold flex items-center gap-1.5">
                        {other.name}
                        <span className="text-[9px] font-black uppercase text-[#00a884] bg-[#00a884]/10 border border-[#00a884]/20 px-1.5 py-0.5 rounded-md">
                          {other.role}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-[9px] text-gray-400 font-medium">
                        <span>Secure Connection</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="flex items-center gap-3">
                <span className="text-[10px] text-gray-400 font-mono tracking-wider hidden sm:block">
                  SECURE END-TO-END SYSTEM
                </span>
                {(currentUser.role === "admin" || currentUser.role === "agent" || activeConv.participants?.includes(currentUser.id)) && (
                  <button
                    onClick={() => handleDeleteConversation(activeConv.id)}
                    className={`p-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 font-bold text-xs ${
                      confirmDeleteId === activeConv.id
                        ? "bg-red-500 text-white hover:bg-red-600 animate-pulse"
                        : "text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                    }`}
                    title="Delete Full Conversation History"
                  >
                    <Trash2 className={`w-4 h-4 ${confirmDeleteId === activeConv.id ? "text-white" : "text-red-500"}`} />
                    <span>{confirmDeleteId === activeConv.id ? "Confirm Delete!" : "Delete Chat"}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Messages scroll content area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5" id="chat-messages-area">
              {messages.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-12 h-12 rounded-full bg-[#00a884]/10 text-[#00a884] flex items-center justify-center mx-auto mb-3 text-xl">
                    💬
                  </div>
                  <h4 className="text-xs font-extrabold uppercase text-gray-500 tracking-wider">No message history</h4>
                  <p className="text-[11px] text-gray-400 mt-1 max-w-xs mx-auto">Write a greeting or upload a reference file to get coordinated in real-time instantly.</p>
                </div>
              ) : (
                (() => {
                  let lastDateLabel = "";
                  return messages.map((m) => {
                    const isSelf = m.senderId === currentUser.id;
                    const dateLabel = formatDateLabel(m.timestamp);
                    const showDateHeader = dateLabel !== lastDateLabel;
                    lastDateLabel = dateLabel;

                    return (
                      <React.Fragment key={m.id}>
                        {showDateHeader && (
                          <div className="text-center my-3">
                            <span className={`text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-md shadow-xs ${
                              isDarkMode ? "bg-[#182229] text-[#8696a0]" : "bg-[#f0f2f5] text-[#667781]"
                            }`}>
                              {dateLabel}
                            </span>
                          </div>
                        )}
                        
                        <div className={`flex ${isSelf ? "justify-end" : "justify-start"}`}>
                          <div className={`max-w-[70%] rounded-lg px-3 py-1.5 text-left text-[12px] shadow-xs relative ${
                            isSelf
                              ? (isDarkMode ? "bg-[#005c4b] text-[#e9edef] rounded-tr-none" : "bg-[#d9fdd3] text-[#303030] rounded-tr-none")
                              : (isDarkMode ? "bg-[#202c33] text-[#e9edef] rounded-tl-none" : "bg-white text-gray-900 rounded-tl-none")
                          }`}>
                            {/* Attachment rendering */}
                            {m.attachment && (
                              <div className={`mb-2 rounded-lg p-2 flex items-center justify-between gap-3 ${
                                isSelf 
                                  ? (isDarkMode ? "bg-[#025143] text-white" : "bg-[#c7f0c2] text-gray-800") 
                                  : (isDarkMode ? "bg-[#182229] text-gray-200" : "bg-[#f0f2f5] text-gray-800")
                              }`}>
                                <div className="flex items-center gap-2 min-w-0">
                                  <FileText className="w-8 h-8 text-[#00a884] flex-shrink-0" />
                                  <div className="text-left min-w-0">
                                    <div className="text-[11px] font-bold truncate max-w-[130px]">{m.attachment.name}</div>
                                    <div className="text-[9px] text-gray-500 font-mono">{m.attachment.size}</div>
                                  </div>
                                </div>
                                <a 
                                  href={m.attachment.url} 
                                  download={m.attachment.name}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className={`p-1.5 rounded-lg transition-colors flex items-center justify-center flex-shrink-0 ${
                                    isSelf 
                                      ? "hover:bg-[#005c4b]/30 text-[#00a884]" 
                                      : "hover:bg-gray-200 dark:hover:bg-[#202c33] text-[#00a884]"
                                  }`}
                                  title="Download File"
                                >
                                  <Download className="w-4 h-4" />
                                </a>
                              </div>
                            )}

                            {/* Message text */}
                            <p className="leading-relaxed break-words whitespace-pre-wrap">{m.text}</p>

                            {/* Info row */}
                            <div className="flex justify-end items-center gap-2 mt-1 select-none text-[9px] text-gray-400 font-medium">
                              <span>{formatTime(m.timestamp)}</span>
                              {isSelf && (
                                m.seen ? (
                                  <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" title="Read receipts" />
                                ) : (
                                  <Check className="w-3.5 h-3.5 text-gray-400" title="Sent safely" />
                                )
                              )}
                              {(isSelf || currentUser.role === "admin" || currentUser.role === "agent") && (
                                <button
                                  onClick={() => handleDeleteMessage(m.id)}
                                  className="text-red-500 hover:text-red-600 transition-colors p-0.5 rounded cursor-pointer ml-1"
                                  title="Delete Message"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  });
                })()
              )}

              {/* Typing users array */}
              {Object.entries(typingUsers).map(([tUserId, typingState]) => {
                if (!typingState) return null;
                const other = activeConv.otherParticipants?.find((p: any) => p.id === tUserId);
                if (!other) return null;

                return (
                  <div key={tUserId} className="flex justify-start items-center gap-2 text-[10px] text-gray-400 italic">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00a884] animate-ping" />
                    <span>{other.name} is typing...</span>
                  </div>
                );
              })}

              <div ref={messageEndRef} />
            </div>

            {/* Input control and toolbar bar */}
            <div className={`p-3 border-t border-[#e9edef] dark:border-[#222e35] ${
              isDarkMode ? "bg-[#202c33]" : "bg-[#f0f2f5]"
            }`}>
              {/* Emoji panel picker */}
              {showEmojiPicker && (
                <div className={`mb-2 p-2.5 rounded-xl border grid grid-cols-10 gap-1.5 ${
                  isDarkMode ? "bg-[#1f2c34] border-[#2f3b43]" : "bg-white border-gray-200"
                }`}>
                  {POPULAR_EMOJIS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => insertEmoji(emoji)}
                      className="text-lg p-1 rounded hover:bg-[#00a884]/15 dark:hover:bg-slate-800 transition-all cursor-pointer text-center"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              <form 
                onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
                className="flex items-center gap-2"
              >
                <button
                  type="button"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                    isDarkMode ? "hover:bg-[#2a3942] text-[#8696a0]" : "hover:bg-gray-200/60 text-[#54656f]"
                  }`}
                  title="Insert Emojis"
                >
                  <Smile className="w-5 h-5" />
                </button>

                <input
                  type="file"
                  className="hidden"
                  ref={fileInputRef}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileUpload(e.target.files[0]);
                    }
                  }}
                />
                
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                    isUploading ? "opacity-50" : ""
                  } ${
                    isDarkMode ? "hover:bg-[#2a3942] text-[#8696a0]" : "hover:bg-gray-200/60 text-[#54656f]"
                  }`}
                  title="Upload attachment / document file"
                >
                  {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Paperclip className="w-5 h-5" />}
                </button>

                <input
                  type="text"
                  placeholder="Type a message..."
                  value={inputMessage}
                  onChange={handleInputChange}
                  className={`flex-1 text-xs px-4 py-2.5 rounded-lg border-none focus:outline-none focus:ring-0 ${
                    isDarkMode 
                      ? "bg-[#2a3942] text-white placeholder-[#8696a0]" 
                      : "bg-white text-gray-950 placeholder-[#667781]"
                  }`}
                />

                <button
                  type="submit"
                  disabled={!inputMessage.trim()}
                  className={`p-2.5 rounded-full transition-all shadow-xs ${
                    inputMessage.trim()
                      ? "bg-[#00a884] hover:bg-[#008f72] text-white cursor-pointer hover:scale-105 active:scale-95"
                      : "bg-gray-250 dark:bg-slate-800 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  <Send className="w-4.5 h-4.5" />
                </button>
              </form>
            </div>
          </>
        ) : (
          /* Landing panel when no active chat */
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center select-none bg-inherit">
            <div className="w-20 h-20 rounded-full bg-[#00a884]/10 text-[#00a884] flex items-center justify-center text-4xl mb-6 shadow-xs border border-[#00a884]/20 animate-pulse">
              💬
            </div>
            <h2 className="text-xl font-bold tracking-tight">Your Direct WhatsApp Portal Coordinator</h2>
            <p className="text-xs text-gray-500 max-w-sm mt-2 leading-relaxed">
              Securely message our admission desk agents and primary administrative coordinators instantly. Receive live replies, notifications, and send attachments in a unified space.
            </p>
            <button
              onClick={loadDirectoryUsers}
              className="mt-6 px-5 py-2.5 bg-[#00a884] text-white text-xs font-bold rounded-xl hover:bg-[#008f72] transition-all shadow hover:shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <UserPlus className="w-4 h-4" /> Start fresh discussion
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
